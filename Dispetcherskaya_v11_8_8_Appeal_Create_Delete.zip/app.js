/* Диспетчерская — версия 11.8.7 · стабильная запись Excel и названия проблем в нижнем регистре. */
(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const esc = (v='') => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const norm = v => String(v ?? '').toLowerCase().replace(/ё/g,'е').replace(/[^a-zа-я0-9]+/gi,' ').trim();
  function normalizeChannel(value){
    const raw=String(value??'').trim();const n=norm(raw);
    if(!n)return '';
    if(n.includes('портал'))return 'портал';
    if(n.includes('почт')||n.includes('email')||n.includes('e mail'))return 'почта';
    if((n.includes('общий')||n.includes('общая'))&&n.includes('телефон'))return 'общий телефон стойки регистрации';
    if(n.includes('стойка')&&(/(^| )a$/.test(n)||n.includes('корпус a')))return 'стойка регистрации корпуса A';
    if(n.includes('стойка')&&(/(^| )b$/.test(n)||n.includes('корпус b')))return 'стойка регистрации корпуса B';
    if(n.includes('стойка'))return 'стойка регистрации';
    return raw;
  }
  function channelFilterKey(value){
    const channel=normalizeChannel(value);
    if(!channel)return 'missing';
    if(channel==='портал')return 'portal';
    if(channel==='почта')return 'email';
    if(channel==='стойка регистрации корпуса A')return 'desk-a';
    if(channel==='стойка регистрации корпуса B')return 'desk-b';
    if(channel==='общий телефон стойки регистрации')return 'desk-phone';
    return 'other';
  }
  function appealBuilding(a){
    const fromChannel=channelFilterKey(a.channel);const work=state.works?.find(w=>w.id===a.workId);
    return String(a.building||work?.building||(fromChannel==='desk-a'?'A':fromChannel==='desk-b'?'B':'')).toUpperCase();
  }
  function appealRoom(a){
    const work=state.works?.find(w=>w.id===a.workId);
    return String(a.room||work?.rooms?.[0]||work?.location||'').trim();
  }
  function locationMissing(a){
    return !appealBuilding(a)||!appealRoom(a);
  }
  function locationMissingText(a){
    const missing=[];
    if(!appealBuilding(a))missing.push('Корпус');
    if(!appealRoom(a))missing.push('Помещение');
    return missing;
  }
  function isManagementCompanyOwner(owner){
    const value=norm(owner);
    if(!value||value.includes('не управля'))return false;
    return value==='ук'||(value.includes('управляющ')&&value.includes('компан'));
  }
  function spaceForAddress(building,room,spaces=state.spaces){
    const b=String(building||'').trim().toUpperCase();
    const raw=String(room||'').trim();
    if(!raw)return null;
    const keys=new Set([norm(raw),norm(canonicalRoomValue(raw,b)),norm(roomInputValue(raw,b))].filter(Boolean));
    return (spaces||[]).find(sp=>{
      if(b&&String(sp.building||'').trim().toUpperCase()!==b)return false;
      return [sp.room,sp.alias].some(value=>value&&keys.has(norm(value)));
    })||null;
  }
  function ownerForAppeal(a){
    const space=spaceForAddress(appealBuilding(a),appealRoom(a));
    return String(space?.owner||'').trim();
  }
  function spacesForWork(w,spaceDirectory=state.spaces){
    if(!w)return [];
    const locations=(Array.isArray(w.rooms)&&w.rooms.some(Boolean))?[...new Set(w.rooms.map(x=>String(x||'').trim()).filter(Boolean))]:[String(w.location||'').trim()].filter(Boolean);
    if(!locations.length)return [];
    return locations.map(room=>spaceForAddress(w.building,room,spaceDirectory));
  }
  function ownerForWork(w,spaceDirectory=state.spaces){
    const spaces=spacesForWork(w,spaceDirectory);
    if(!spaces.length||spaces.some(sp=>!sp))return '';
    const outside=spaces.find(sp=>!isManagementCompanyOwner(sp.owner));
    return String((outside||spaces[0])?.owner||'').trim();
  }
  function clarificationRoomForWork(w){
    const rooms=[...new Set((w?.rooms||[]).map(x=>String(x||'').trim()).filter(Boolean))];
    if(rooms.length===1)return rooms[0];
    if(!rooms.length&&w?.location&&spaceForAddress(w.building,w.location))return String(w.location).trim();
    return '';
  }
  function requiresClarification(a){
    const serviceNeedsCheck=(a?.missing||[]).some(item=>norm(item).includes('обслуживающ'));
    return locationMissing(a)||!isManagementCompanyOwner(ownerForAppeal(a))||serviceNeedsCheck;
  }
  function clarificationReasonText(a){
    const reasons=locationMissingText(a);
    const owner=ownerForAppeal(a);
    if(!isManagementCompanyOwner(owner))reasons.push(owner?`обслуживает ${owner}`:'не подтверждено обслуживание управляющей компанией');
    else if((a?.missing||[]).some(item=>norm(item).includes('обслуживающ')))reasons.push('обслуживающая организация требует проверки');
    return reasons.join(', ')||'требуется проверка обслуживающей организации';
  }
  function sendAppealToClarification(a,{building='',room='',owner=null,reason='',force=false}={}){
    if(a.workId||state.works.some(w=>(w.appealIds||[]).includes(a.id)))unlinkAppeal(a);
    if(building)a.building=String(building).trim().toUpperCase();
    if(room)a.room=String(room).trim();
    const space=spaceForAddress(a.building,a.room);
    if(space){a.building=a.building||space.building;a.room=a.room||space.room;a.zone=a.zone||space.zone||'';}
    // Источник истины — справочник помещений. Не переносим устаревшего владельца на новый адрес.
    // Владелец берётся только из справочника по итоговому адресу, а не из ответа модели или старой карточки.
    a.owner=String(space?.owner||'').trim();
    a.route=a.owner&&!isManagementCompanyOwner(a.owner)?'tenant':'';
    a.routeText=a.owner?`Обслуживает: ${a.owner}`:'Обслуживающая организация не подтверждена';
    a.workId='';a.duplicateOf='';a.manualUnlinked=true;
    a.needsClarification=true;
    a.missing=(a.missing||[]).filter(x=>!/(корпус|помещен)/i.test(x));
    if(!a.building)a.missing.push('Корпус');
    if(!a.room)a.missing.push('Помещение');
    if((force||!isManagementCompanyOwner(a.owner))&&!a.missing.some(x=>norm(x).includes('обслуживающ')))a.missing.push('Обслуживающая организация');
    a.linkReason=reason||'Требуется проверка места или обслуживающей организации.';
    return 'clarify';
  }
  function roomInputValue(room,building=''){let value=String(room||'').trim();if(!value)return '';const b=String(building||'').trim().toUpperCase();if(b)value=value.replace(new RegExp('^'+b+'\\s*[-–]?\\s*','i'),'');value=value.replace(/^корпус\s+[AB]\s*/i,'');return value;}
  function canonicalRoomValue(room,building=''){let value=String(room||'').trim().replace(/^корпус\s+[AB]\s*/i,'');const b=String(building||'').trim().toUpperCase();const coded=value.match(/^([AB])\s*[-–]?\s*(\d{3})$/i);if(coded)return (b||coded[1].toUpperCase())+'-'+coded[2];if(b&&/^\d{3}$/.test(value))return b+'-'+value;return value;}
  function displayWorkId(id){const raw=String(id||'').trim();const m=raw.match(/^([РR])\s*([ПP])?\s*[-–]?\s*(\d+)$/i);return m?'Р-'+String(Number(m[3])).padStart(2,'0'):raw;}
  function workIdKey(id){return displayWorkId(id).toUpperCase().replace(/[^Р0-9]/g,'');}
  function extractWorkReference(text,works){const rx=/(?:по\s+)?работ(?:а|е|у|ой|ы)?\s*(?:№|#|:)?\s*([РR])\s*(?:[ПP]\s*)?[-–]?\s*0*(\d{1,4})/gi;let m;while((m=rx.exec(String(text||'')))){const key=workIdKey('Р-'+m[2]);const found=(works||[]).find(w=>workIdKey(w.id)===key);if(found)return found;}return null;}
  const state = {data:null, appeals:[], works:[], spaces:[], rules:[], view:'overview', selectedAppeal:null, selectedProblemWork:null, selectedMessage:null, selectedWork:null, query:'', filter:'all', appealChannelFilter:'all', appealBuildingFilter:'all', overviewBuildingFilter:'all', workSort:'newest', workStatusFilter:'all', sourceName:'case_data.xlsx', revision:'', appRevision:'', appState:{tenantQuestions:{},tenantMessages:{},aiRouting:{},problemTitles:{}}, aiStatus:null, aiBusy:false, aiAnswer:{}, history:[]};
  let saveTimer=null, saving=false, saveAgain=false, polling=false, routingQueue=Promise.resolve();

  function firstHeader(rows, predicate){
    for(let i=0;i<Math.min(rows.length,12);i++){
      const cells=(rows[i]||[]).map(x=>norm(x));
      if(predicate(cells)) return i;
    }
    return -1;
  }
  function col(headers, names){
    const h=headers.map(norm);
    for(const n of names){const idx=h.indexOf(norm(n));if(idx>=0)return idx;}
    for(let i=0;i<h.length;i++){if(names.some(n=>h[i].includes(norm(n))))return i;}
    return -1;
  }
  function cell(row, idx){return idx<0?'':String(row?.[idx]??'').trim();}
  function parseRaw(raw){
    const entries=Object.entries(raw||{});
    const sheet=(terms)=>entries.find(([n])=>terms.some(t=>norm(n).includes(norm(t))))?.[1]||[];
    const ar=sheet(['Обращения','Заявки']);
    const sp=sheet(['Помещения','Справочник помещений']);
    const wo=sheet(['Работы','Исполнители']);
    const ru=sheet(['Правила']);
    const ah=firstHeader(ar,h=>h.includes('время')&&h.includes('заявитель')&&h.includes('текст обращения'));
    const sh=firstHeader(sp,h=>h.includes('корпус')&&h.includes('помещение')&&h.includes('зона обслуживания'));
    const wh=firstHeader(wo,h=>h.includes('номер работы')||h.includes('работы')&&h.includes('исполнитель')&&h.includes('статус'));
    const rh=firstHeader(ru,h=>h.includes('тема')&&h.includes('правило'));
    if(ah<0||sh<0||wh<0){throw new Error('В Excel не найдены обязательные листы/колонки: «Обращения», «Помещения», «Работы». Формат листов должен быть близок к шаблону кейса.');}
    const ahd=ar[ah], shd=sp[sh], whd=wo[wh];
    const appealRows=ar.slice(ah+1).filter(r=>r&&r.some(v=>String(v??'').trim()));
    const spaceRows=sp.slice(sh+1).filter(r=>r&&r.some(v=>String(v??'').trim()));
    const workRows=wo.slice(wh+1).filter(r=>r&&r.some(v=>String(v??'').trim()));
    const ruleRows=rh>=0?ru.slice(rh+1).filter(r=>r&&r.some(v=>String(v??'').trim())):[];
    const appeals=appealRows.map((r,i)=>{
      const clarCol=col(ahd,['Требует уточнения']);
      const clarValue=cell(r,clarCol);
      const missingText=cell(r,col(ahd,['Что уточнить']));
      const routeValue=cell(r,col(ahd,['Маршрут']));
      return {
        id:cell(r,col(ahd,['№','Номер','ID']))||`О-${String(i+1).padStart(2,'0')}`,
        time:cell(r,col(ahd,['Время','Дата и время'])),channel:cell(r,col(ahd,['Канал','Источник'])),
        portal:cell(r,col(ahd,['Номер на портале','Номер портала','Portal ID'])) || ((cell(r,col(ahd,['Текст обращения','Текст','Описание'])).match(/\bP\d+\b/i)||[])[0]||''),
        reporter:cell(r,col(ahd,['Заявитель','От кого','Автор'])),text:cell(r,col(ahd,['Текст обращения','Текст','Описание'])),
        building:cell(r,col(ahd,['Корпус'])),room:cell(r,col(ahd,['Помещение'])),sourceBuilding:cell(r,col(ahd,['Корпус'])),sourceRoom:cell(r,col(ahd,['Помещение'])),zone:cell(r,col(ahd,['Зона обслуживания','Зона'])),
        workId:displayWorkId(cell(r,col(ahd,['Связанная работа','№ работы']))),priority:cell(r,col(ahd,['Приоритет'])),
        storedClarification:clarValue===''?null:/^(да|yes|true|1)$/i.test(clarValue),
        storedMissing:missingText?missingText.split(/[;|]/).map(x=>x.trim()).filter(Boolean):null,
        aiSummary:cell(r,col(ahd,['Сводка ИИ'])),responseDraft:cell(r,col(ahd,['Ответ заявителю'])),
        route:routeValue==='tenant'||norm(routeValue).includes('арендатор')?'tenant':'',routeText:routeValue,
        manualUnlinked:/^(да|yes|true|1)$/i.test(cell(r,col(ahd,['Ручная привязка']))),
        linkReason:cell(r,col(ahd,['Причина связи'])),duplicateOf:cell(r,col(ahd,['Дубликат'])),changeLog:cell(r,col(ahd,['История изменений']))
      };
    });
    const spaces=spaceRows.map(r=>({
      building:cell(r,col(shd,['Корпус'])),room:cell(r,col(shd,['Помещение'])),alias:cell(r,col(shd,['Как ещё называют','Как еще называют','Альтернативное название'])),
      floor:cell(r,col(shd,['Этаж'])),zone:cell(r,col(shd,['Зона обслуживания','Зона'])),tenant:cell(r,col(shd,['Арендатор'])),owner:cell(r,col(shd,['Кто обслуживает','Обслуживает']))
    }));
    const works=workRows.map(r=>({
      id:displayWorkId(cell(r,col(whd,['№ работы','Номер работы','Работа']))),building:cell(r,col(whd,['Корпус'])),location:cell(r,col(whd,['Помещение или зона','Помещение','Зона'])),zone:cell(r,col(whd,['Зона обслуживания','Зона'])),
      executor:cell(r,col(whd,['Исполнитель'])),status:cell(r,col(whd,['Статус'])),updated:cell(r,col(whd,['Статус обновлён','Статус обновлен','Обновлено'])),
      description:cell(r,col(whd,['Описание'])),related:cell(r,col(whd,['Связанные обращения','Обращения'])),
      priority:cell(r,col(whd,['Приоритет'])),previousWork:displayWorkId(cell(r,col(whd,['Предыдущая работа']))),source:cell(r,col(whd,['Источник'])),aiSummary:cell(r,col(whd,['Сводка ИИ']))
    }));
    const rules=ruleRows.map(r=>({id:cell(r,col(ru[rh],['№','Номер'])),topic:cell(r,col(ru[rh],['Тема'])),text:cell(r,col(ru[rh],['Правило']))}));
    // Empty appeals sheet is valid: the user may delete the last appeal.
    return {appeals,spaces,works,rules};
  }

  function getSpaceForText(text, reporter, spaces){
    const raw=String(text||'');
    const n=norm(raw), rep=norm(reporter);
    const id=(raw.match(/(?:^|\W)([ABАВ])\s*[-–]?\s*(\d{3})(?:\W|$)/i)||[]);
    if(id.length){const building=({А:'A',В:'B'}[id[1].toUpperCase()]||id[1].toUpperCase()), room=building+'-'+id[2];const found=spaces.find(s=>s.building.toUpperCase()===building&&s.room.toUpperCase()===room);return found||{building,room,zone:'',owner:''};}
    const explicitBuildingRaw=(raw.match(/(?:^|[\s,.;:])корпус(?:а|е|у)?\s+([ABАВ])(?=$|[\s,.;:])/i)||[])[1]||'';
    const explicitRoom=(raw.match(/(?:кабинет(?:а|е|у)?|каб\.?(?:а|е|у)?|помещени[еяи]|офис(?:а|е|у)?|комнат(?:а|ы|е|у)?)\s*(?:№|#|N)?\s*(\d{3})\b/i)||[])[1]||'';
    if(explicitBuildingRaw&&explicitRoom){
      const building=({А:'A',В:'B'}[explicitBuildingRaw.toUpperCase()]||explicitBuildingRaw.toUpperCase());
      const room=building+'-'+explicitRoom;
      const found=spaces.find(s=>s.building.toUpperCase()===building&&s.room.toUpperCase()===room);
      if(found)return found;
    }
    if(n.includes('у кофейн')||n.includes('кофейни')) return spaces.find(s=>s.building.toUpperCase()==='B'&&norm(s.room).includes('холл'))||null;
    if(n.includes('холл')&&(n.includes('корпус а')||n.includes('холл а')||n.includes('у лифт'))) return spaces.find(s=>s.building.toUpperCase()==='A'&&norm(s.room).includes('холл'))||null;
    if(n.includes('холл')&&n.includes('корпус b')) return spaces.find(s=>s.building.toUpperCase()==='B'&&norm(s.room).includes('холл'))||null;
    // По разговорному названию из справочника; арендатора используем только как дополнительный контекст.
    const aliases=spaces.filter(s=>s.alias).sort((a,b)=>norm(b.alias).length-norm(a.alias).length);
    for(const s of aliases){
      const alias=norm(s.alias), chunks=alias.split(' ').filter(w=>w.length>3);
      if(alias&&n.includes(alias)) return s;
      if(chunks.length>=2&&chunks.every(w=>n.includes(w))) return s;
    }
    if(n.includes('серверн')&&rep.includes('дельта софт')) return spaces.find(s=>s.building==='A'&&s.room==='A-206')||null;
    if(n.includes('переговорн')&&n.includes('ока')) return spaces.find(s=>s.building==='A'&&s.room==='A-310')||null;
    if(n.includes('у лифт')&&n.includes('корпус a')) return spaces.find(s=>s.building==='A'&&norm(s.room).includes('холл'))||null;
    return null;
  }
  function categoryOf(text){
    const n=norm(text);
    if(/створк|окно.*не закры|не закры.*окн|окн.*не откры|не откры.*окн/.test(n))return 'окно';
    if(/ручк|двер/.test(n))return 'дверь';
    if(/светильник|не горит свет|ламп/.test(n))return 'освещение';
    if(/розет/.test(n))return 'электрика';
    if(/серверн|кондиционер|гудит/.test(n))return 'кондиционер';
    if(/холод|прохлад|температур|градус|батаре|дует/.test(n))return 'температура';
    if(/раковин|капает|теч|сантех/.test(n))return 'сантехника';
    if(/поскольз|разлит|пролит|вод.*пол|пятн.*пол|полу/.test(n))return 'пролив на полу';
    if(/пятн|уборк|гряз/.test(n))return 'уборка';
    return 'прочее';
  }
  function shortIssue(cat){return ({'температура':'холодно в помещении','дверь':'неисправность двери','освещение':'не работает светильник','электрика':'не работают розетки','окно':'не закрывается окно','кондиционер':'шум кондиционера','сантехника':'течь / сантехника','пролив на полу':'вода на полу','уборка':'нужна уборка','прочее':'требуется осмотр'})[cat]||cat;}
  function fallbackProblemTitle(description){
    const text=String(description||'').replace(/\s+/g,' ').trim();
    if(!text)return 'требуется осмотр';
    const category=categoryOf(text);
    if(category&&category!=='прочее')return shortIssue(category);
    const first=(text.split(/[.!?;\n]/).find(Boolean)||text).trim()
      .replace(/^(?:корпус\s+[AB][, :–-]*)?/i,'')
      .replace(/^[AB]\s*[-–]\s*\d{3}\s*[:,-]\s*/i,'')
      .replace(/^(?:в|во|на)\s+(?:корпусе|помещении|кабинете)\s+[AB0-9-]+[, :–-]*/i,'')
      .trim();
    const words=first.split(/\s+/).filter(Boolean);
    let title=words.slice(0,7).join(' ').replace(/[,:;.!?]+$/,'').trim();
    if(title.length>68)title=title.slice(0,65).replace(/\s+\S*$/,'')+'…';
    return cleanProblemTitle(title||'требуется осмотр','требуется осмотр');
  }
  function cleanProblemTitle(value,fallback='требуется осмотр'){
    let title=String(value||'').replace(/[\r\n]+/g,' ').replace(/^\s*[«"']|[»"']\s*$/g,'').replace(/^название\s*:\s*/i,'').replace(/\s+/g,' ').trim();
    title=title.replace(/[.!?;:,]+$/,'').trim();
    if(!title||title.length<3)return String(fallback).toLocaleLowerCase('ru-RU');
    if(title.length>76)title=title.slice(0,73).replace(/\s+\S*$/,'')+'…';
    return title.toLocaleLowerCase('ru-RU');
  }
  function rememberProblemTitle(workId,title){
    const key=String(workId||'').trim();if(!key)return;
    state.appState=state.appState||{};state.appState.problemTitles=state.appState.problemTitles||{};
    const cleaned=cleanProblemTitle(title,'');if(cleaned)state.appState.problemTitles[key]=cleaned;
  }
  function problemTitleForWork(work){
    if(!work)return '';
    const stored=state.appState?.problemTitles?.[work.id];
    return cleanProblemTitle(stored,'')||fallbackProblemTitle(work.description||work.category||'');
  }
  function statusClass(status){const s=norm(status);if(s.includes('в работе'))return 'status-progress';if(s.includes('принято'))return 'status-accepted';if(s.includes('открыто'))return 'status-open';if(s.includes('закрыто'))return 'status-closed';if(s.includes('у арендат'))return 'status-tenant';return 'status-clarify';}
  function statusLabel(s){return s||'не задан';}
  function isResolvedStatus(status){const n=norm(status);return ['закрыто','решено','решена','решен','выполнено','выполнена','завершено','завершена','устранено','устранена'].some(x=>n===x||n.startsWith(x+' '));}
  function isResolvedGroup(group){
    return !!group.work&&isResolvedStatus(group.status);
  }
  function isResolvedThanks(text){return /устранили|починили|выполнено|убрали|спасибо|решено/.test(norm(text));}
  function isRecurrence(text){return /снова|опять|по прежнему|по прежнему|все еще|всё ещё|до сих пор|так и не|не работает|не устранили/.test(norm(text));}
  function roomList(location){const m=[...String(location||'').matchAll(/\b([AB])\s*[-–]?\s*(\d{3})\b/gi)];return [...new Set(m.map(x=>x[1].toUpperCase()+'-'+x[2]))];}
  function roomNumberTokens(value){
    const text=String(value||'');
    const tokens=roomList(text).map(x=>(x.match(/(\d{3})$/)||[])[1]).filter(Boolean);
    const bare=[...text.matchAll(/(?:кабинет|каб\.?|помещени[еяи]|офис|комната)\s*(?:№|#|N)?\s*(\d{3})\b/gi)].map(x=>x[1]);
    return [...new Set([...tokens,...bare])];
  }
  function workLocationConflicts(text,sourceBuilding,sourceRoom,work,spaceDirectory=state.spaces,reporter=''){
    const source=String(text||'')+' '+String(sourceRoom||'');
    const mentioned=roomNumberTokens(source);
    if(String(sourceRoom||'').trim()&&/^\d{3}$/.test(String(sourceRoom).trim()))mentioned.push(String(sourceRoom).trim());
    const known=roomNumberTokens([...(work?.rooms||[]),work?.location||''].join(' '));
    let roomConflict=!!(mentioned.length&&known.length&&!mentioned.some(x=>known.includes(x)));
    const rawBuilding=String(sourceBuilding||'').trim().toUpperCase();
    // Учитываем не только номера A-206, но и разговорные названия из справочника.
    const explicitSpace=spaceForAddress(rawBuilding,sourceRoom,spaceDirectory)||getSpaceForText(source,reporter,spaceDirectory);
    if(explicitSpace){
      const targetRooms=(Array.isArray(work?.rooms)&&work.rooms.length?work.rooms:[work?.location||'']).filter(Boolean);
      const targetSpaces=targetRooms.map(room=>spaceForAddress(work?.building,room,spaceDirectory)).filter(Boolean);
      if(targetSpaces.length&&!targetSpaces.some(sp=>sp.building===explicitSpace.building&&norm(sp.room)===norm(explicitSpace.room)))roomConflict=true;
    }
    const textBuilding=(String(text||'').match(/корпус\s+([AB])\b/i)||[])[1]||'';
    const codedBuilding=(String(text||'').match(/(?:^|\W)([AB])\s*[-–]\s*\d{3}(?:\W|$)/i)||[])[1]||'';
    const explicitBuilding=rawBuilding==='A'||rawBuilding==='B'?rawBuilding:(textBuilding||codedBuilding).toUpperCase();
    const buildingConflict=!!(explicitBuilding&&work?.building&&explicitBuilding!==String(work.building).toUpperCase());
    return !!(roomConflict||buildingConflict);
  }
  function normalizeWork(w,spaces){
    const ids=roomList(w.location);
    let space=ids.length?spaces.find(s=>norm(s.room)===norm(ids[0])):null;
    if(!space&&w.location){
      const exact=spaces.find(s=>norm(s.room)===norm(w.location)&&(!w.building||s.building.toUpperCase()===w.building.toUpperCase()));
      space=exact||null;
    }
    if(!space&&norm(w.location).includes('холл')) space=spaces.find(s=>s.building.toUpperCase()===(w.building||'').toUpperCase()&&norm(s.room).includes('холл'));
    const category=categoryOf(w.description+' '+w.location);
    const building=w.building||space?.building||'';
    const zone=w.zone||space?.zone||'';
    const location=w.location||(ids.join(', '))||(space?.room||'');
    return {...w,building,location,zone,rooms:ids.length?ids:(space?[space.room]:[]),space:space||null,category,appealIds:(w.related||'').split(/[,;]+/).map(x=>x.trim()).filter(Boolean),source:w.source||'existing',needsClarification:false,notes:[]};
  }
  function buildModel(parsed){
    const spaces=parsed.spaces;
    const works=parsed.works.map(w=>normalizeWork(w,spaces));
    const appeals=parsed.appeals.map(a=>{
      let sp=spaceForAddress(a.building,a.room,spaces);
      if(!sp)sp=getSpaceForText(a.text,a.reporter,spaces);
      const cat=categoryOf(a.text);
      const storedMissing=(a.storedMissing||[]).filter(m=>{
        const n=norm(m);
        if(n.includes('корпус'))return !a.building&&!sp?.building;
        if(n.includes('помещен'))return !a.room&&!sp?.room;
        if(n.includes('заявител')||n.includes('контакт'))return !a.reporter||norm(a.reporter)==='не записан';
        return true;
      });
      return {...a,building:a.building||sp?.building||'',room:a.room||sp?.room||'',zone:a.zone||sp?.zone||'',owner:sp?.owner||'',category:cat,issue:shortIssue(cat),workId:a.workId||'',needsClarification:!!a.storedClarification&&storedMissing.length>0,missing:storedMissing,route:a.route||'',priority:a.priority||(/поскольз|гости жалуются|до 13 00/.test(norm(a.text))?'Высокий':'Обычный'),source:'incoming',duplicateOf:a.duplicateOf||'',aiSummary:a.aiSummary||'',responseDraft:a.responseDraft||''};
    });
    const appById=new Map(appeals.map(a=>[a.id,a]));
    const workById=new Map(works.map(w=>[w.id,w]));
    const attach=(a,w,reason='')=>{
      a.workId=w.id;a.manualUnlinked=false;
      if(!a.building&&w.building)a.building=w.building;
      if(!a.room)a.room=(w.rooms||[]).find(Boolean)||w.location||'';
      if(!a.zone&&w.zone)a.zone=w.zone;
      if(norm(a.category)==='прочее'&&w.category){a.category=w.category;a.issue=w.description||shortIssue(w.category);}
      if(!w.appealIds.includes(a.id))w.appealIds.push(a.id);
      if(reason)a.linkReason=reason;
    };
    // Прежде всего сохраняем связи из выгрузки исполнителей и из явного поля обращения.
    // Если в строке обращения явно задана другая работа, она имеет приоритет над старой связью в листе работ.
    works.forEach(w=>{w.appealIds=(w.appealIds||[]).filter(id=>{const a=appById.get(id);return !a||(!a.manualUnlinked&&(!a.workId||a.workId===w.id));});});
    works.forEach(w=>w.appealIds.forEach(id=>{const a=appById.get(id);if(a)attach(a,w,'Связь из исходной системы работ');}));
    appeals.forEach(a=>{if(a.workId&&!a.manualUnlinked){const w=workById.get(a.workId);if(w)attach(a,w,a.linkReason||'Связь из карточки обращения');}});
    // Если в тексте есть ссылка «по работе Р-04», привязываем к этой работе.
    // Но явный другой кабинет/характер неисправности имеет приоритет над противоречащим номером.
    appeals.forEach(a=>{
      if(a.workId||a.manualUnlinked)return;
      const referenced=extractWorkReference(a.text,works);if(!referenced)return;
      const locationConflict=workLocationConflicts(a.text,a.sourceBuilding||a.building,a.sourceRoom||a.room,referenced,spaces,a.reporter);
      const textCategory=categoryOf(a.text);
      const categoryConflict=textCategory!=='прочее'&&referenced.category&&textCategory!==referenced.category;
      if(!locationConflict&&!categoryConflict){
        if(!isManagementCompanyOwner(ownerForWork(referenced,spaces))){
          const referencedRooms=(referenced.rooms||[]).filter(Boolean);
          if(referencedRooms.length===1){a.building=a.building||referenced.building||'';a.room=a.room||referencedRooms[0];}
          if(referencedRooms.length!==1&&!a.missing.some(x=>norm(x).includes('обслуживающ')))a.missing.push('Обслуживающая организация');
          a.linkReason='Упомянутая работа не подтверждена как полностью обслуживаемая управляющей компанией.';
          return;
        }
        attach(a,referenced,'Номер работы указан в тексте обращения');
      }
    });
    let next=works.reduce((n,w)=>Math.max(n,Number((w.id.match(/\d+/)||[])[0]||0),n),0)+1;
    const makeWork=(a,old=null)=>{
      const id='Р-'+String(next++).padStart(2,'0');
      const w={id,building:a.building,location:a.room||'Помещение уточняется',zone:a.zone||'—',executor:'Не назначен',status:'открыто',updated:workStamp(),description:a.issue,rooms:a.room?[a.room]:[],space:spaces.find(s=>s.room===a.room)||null,category:a.category,appealIds:[],source:'pilot',needsClarification:false,notes:[],previousWork:old?.id||''};
      works.push(w);workById.set(id,w);attach(a,w,old?`Повтор после ${old.id}`:'Новая неисправность');return w;
    };
    for(const a of appeals){
      if(a.workId||a.manualUnlinked) continue;
      const n=norm(a.text);
      // Дубли одного портального номера сохраняются как отдельные входящие, но не создают работу.
      const dup=appeals.find(x=>x!==a&&a.portal&&x.portal===a.portal&&x.workId);
      if(dup){a.duplicateOf=dup.id;const w=workById.get(dup.workId);if(w)attach(a,w,'Повтор того же номера портала');continue;}
      if(!isManagementCompanyOwner(a.owner)){
        a.route=a.owner?'tenant':'';a.needsClarification=true;
        a.routeText=a.owner?`Обслуживает: ${a.owner}`:'Обслуживающая организация не подтверждена';
        continue;
      }
      const matches=works.filter(w=>{
        const active=norm(w.status)!=='закрыто';
        if(!active||!isManagementCompanyOwner(ownerForWork(w,spaces))) return false;
        if(a.category==='температура') return a.zone&&w.zone===a.zone&&w.category==='температура';
        if(!a.room) return false;
        const sameRoom=(w.rooms||[]).includes(a.room)||w.location===a.room;
        return sameRoom&&w.category===a.category;
      });
      if(matches.length){
        const w=matches[0];attach(a,w,'Та же зона и неисправность');
        if(/встреча|гости/.test(n)){a.priority='Высокий';a.needsClarification=false;}
        continue;
      }
      const closedMatches=works.filter(w=>{
        if(norm(w.status)!=='закрыто'||!isManagementCompanyOwner(ownerForWork(w,spaces))) return false;
        if(a.category==='температура') return a.zone&&w.zone===a.zone&&w.category==='температура';
        return a.room&&((w.rooms||[]).includes(a.room)||w.location===a.room)&&w.category===a.category;
      });
      if(closedMatches.length&&isResolvedThanks(a.text)){
        attach(a,closedMatches[0],'Подтверждение результата закрытой работы');continue;
      }
      if(closedMatches.length&&isRecurrence(a.text)){
        a.workId=closedMatches[0].id;a.previousWork=closedMatches[0].id;a.needsClarification=false;
        a.missing.push('Когда проблема появилась повторно');a.linkReason='После закрытия: нужно уточнить время повторения';
        continue;
      }
      if(!a.building||!a.room){a.needsClarification=true;if(!a.building)a.missing.push('Корпус');if(!a.room)a.missing.push('Помещение');continue;}
      const nw=makeWork(a);
      if(a.priority==='Высокий')nw.priority='Высокий';
    }
    // Сверяем обслуживающую организацию со справочником. Не-УК и неизвестный владелец
    // отправляются в «Нужно уточнить» и не остаются одновременно в обзоре/работах.
    for(const a of appeals){
      if(!a.reporter||norm(a.reporter)==='не записан'){if(!a.missing.includes('Заявитель / контакт'))a.missing.push('Заявитель / контакт');}
      let linked=workById.get(a.workId);
      const ownSpace=spaceForAddress(a.sourceBuilding,a.sourceRoom,spaces)||getSpaceForText(a.text,a.reporter,spaces);
      const rawLocationKnown=!!ownSpace||!!a.sourceBuilding||!!a.sourceRoom;
      // Не оставляем обращение привязанным к работе, если хотя бы одно её помещение
      // не подтверждено справочником как обслуживаемое управляющей компанией.
      if(linked&&!isManagementCompanyOwner(ownerForWork(linked,spaces))){
        if(ownSpace){
          a.building=ownSpace.building;a.room=ownSpace.room;a.zone=ownSpace.zone||a.zone||'';a.owner=ownSpace.owner||'';
        }else if(rawLocationKnown){
          a.building=a.sourceBuilding||a.building||'';a.room=a.sourceRoom||'';a.owner='';
        }else{
          const linkedRooms=(linked.rooms||[]).filter(Boolean);
          a.building=a.building||linked.building||'';
          if(linkedRooms.length===1){a.room=linkedRooms[0];const inheritedSpace=spaceForAddress(a.building,a.room,spaces);a.owner=inheritedSpace?.owner||'';}
          else{a.room='';a.owner='';if(!a.missing.some(x=>norm(x).includes('обслуживающ')))a.missing.push('Обслуживающая организация');}
        }
        linked.appealIds=(linked.appealIds||[]).filter(id=>id!==a.id);
        if(linked.source==='pilot'&&!linked.appealIds.length){const index=works.indexOf(linked);if(index>=0)works.splice(index,1);workById.delete(linked.id);}
        a.workId='';a.duplicateOf='';a.manualUnlinked=true;linked=null;
        a.linkReason='Связь с работой снята: обслуживание всех помещений этой работы не подтверждено управляющей компанией.';
      }
      const linkedRoom=(linked?.rooms||[]).find(Boolean)||linked?.location||'';
      const resolvedSpace=ownSpace||spaceForAddress(a.building||linked?.building,a.room||linkedRoom,spaces);
      if(resolvedSpace){a.building=a.building||resolvedSpace.building;a.room=a.room||resolvedSpace.room;a.zone=a.zone||resolvedSpace.zone||'';a.owner=resolvedSpace.owner||'';}
      if(!a.building&&!a.missing.includes('Корпус'))a.missing.push('Корпус');
      if(!a.room&&!a.missing.includes('Помещение'))a.missing.push('Помещение');
      const managementOwned=isManagementCompanyOwner(a.owner);
      if(!managementOwned&&a.workId){
        const oldWork=workById.get(a.workId);
        if(oldWork){
          oldWork.appealIds=(oldWork.appealIds||[]).filter(id=>id!==a.id);
          if(oldWork.source==='pilot'&&!oldWork.appealIds.length){
            const index=works.indexOf(oldWork);if(index>=0)works.splice(index,1);
            workById.delete(oldWork.id);
          }
        }
        a.workId='';a.duplicateOf='';a.manualUnlinked=true;
      }
      if(!managementOwned){
        a.manualUnlinked=true;
        if(a.duplicateOf)a.duplicateOf='';
        a.route=a.owner?'tenant':'';
        a.routeText=a.owner?`Обслуживает: ${a.owner}`:'Обслуживающая организация не подтверждена';
      }else if(a.route==='tenant'){
        a.route='';a.routeText='';
      }
      a.needsClarification=!(a.building&&a.room)||!managementOwned||a.missing.some(x=>norm(x).includes('обслуживающ'));
      if(a.workId){const w=workById.get(a.workId);if(w&&norm(w.status)==='закрыто'&&isRecurrence(a.text)&&!isResolvedThanks(a.text)){if(!a.missing.includes('Когда проблема появилась повторно'))a.missing.push('Когда проблема появилась повторно');}}
    }
    return {appeals,works,spaces,rules:parsed.rules};
  }

  function loadData(raw,name='case_data.xlsx',revision='',appState=null,appRevision=''){
    const firstLoad=!state.data;
    const hadLegacyWorkHistory=!!(appState&&typeof appState==='object'&&Object.prototype.hasOwnProperty.call(appState,'workHistory'));
    const previousAppeals=new Map(state.appeals.map(a=>[a.id,appealRoutingFingerprint(a)]));
    const parsed=parseRaw(raw);const model=buildModel(parsed);
    state.data=raw;state.appeals=model.appeals;state.works=model.works;state.spaces=model.spaces;state.rules=model.rules;state.sourceName=name;state.revision=revision||state.revision;state.appRevision=appRevision||state.appRevision;if(appState&&typeof appState==='object')state.appState={...appState,tenantQuestions:appState.tenantQuestions||{},tenantMessages:appState.tenantMessages||{},aiRouting:appState.aiRouting||{},problemTitles:appState.problemTitles||{}};
    state.appState.problemTitles=state.appState.problemTitles||{};
    delete state.appState.workHistory;
    state.appeals.forEach(a=>{const meta=state.appState.tenantMessages?.[a.id];if(meta){if(meta.responseDraft)a.responseDraft=meta.responseDraft;if(meta.aiSummary)a.aiSummary=meta.aiSummary;}});
    state.history=model.appeals.flatMap(a=>(a.changeLog||'').split('\n').filter(Boolean).map(line=>{const cut=line.indexOf(' · ');return {appealId:a.id,time:cut>=0?line.slice(0,cut):'',text:cut>=0?line.slice(cut+3):line};}));const sourceLabel=document.querySelector('#sourceLabel');if(sourceLabel)sourceLabel.textContent='Книга: data/active.xlsx · '+name;
    // При внешнем обновлении книги сохраняем текущую вкладку, фильтр и поисковый запрос.
    if(state.selectedAppeal&&!state.appeals.some(a=>a.id===state.selectedAppeal))state.selectedAppeal=null;
    if(state.selectedProblemWork&&!state.works.some(w=>w.id===state.selectedProblemWork))state.selectedProblemWork=null;
    if(state.selectedMessage&&!state.appeals.some(a=>a.id===state.selectedMessage))state.selectedMessage=null;
    if(state.selectedWork&&!state.works.some(w=>w.id===state.selectedWork))state.selectedWork=null;
    updateNav();render();
    if(hadLegacyWorkHistory)queueSave();
    if(!firstLoad){
      const changed=model.appeals.filter(a=>!previousAppeals.has(a.id)||previousAppeals.get(a.id)!==appealRoutingFingerprint(a));
      if(changed.length)queueAutoRouting(changed);
    }else if(hasGeminiConsent()&&model.appeals.length){
      // При первом запуске обрабатываем только самое последнее обращение, а не всю архивную книгу.
      queueAutoRouting([model.appeals[model.appeals.length-1]]);
    }
  }
  function updateNav(){
    const count=state.appeals.filter(requiresClarification).length;
    const clarify=$('#navClarifyCount');
    if(clarify){clarify.textContent=count;clarify.classList.toggle('is-empty',count===0);clarify.title=count?`${count} обращений требуют уточнения места или обслуживающей организации`:'Нет обращений для уточнения';}
  }
  function setSyncStatus(text,kind=''){
    const el=$('#syncStatus');if(!el)return;el.textContent=text;el.className='sync-state '+kind;
  }
  function queueSave(){
    if(saveTimer)clearTimeout(saveTimer);
    setSyncStatus('Сохранение в Excel…','sync-pending');
    saveTimer=setTimeout(saveWorkbook,220);
  }
  async function saveWorkbook(){
    saveTimer=null;
    if(saving){saveAgain=true;return;}
    saving=true;
    const expectedRevision=state.revision;
    const payload={revision:expectedRevision,appRevision:state.appRevision,appeals:state.appeals,works:state.works,appState:state.appState};
    try{
      const response=await fetch('/api/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const data=await response.json();
      if(response.status===409){setSyncStatus('Есть внешние изменения','sync-warn');await refreshWorkbook(true);toast('Книга Excel изменилась в другом окне. Обновили данные — повтори последнее действие.','warn');return;}
      if(!response.ok)throw new Error(data.error||'Не удалось сохранить книгу Excel');
      state.revision=data.revision;state.appRevision=data.appRevision||state.appRevision;setSyncStatus('Excel синхронизирован','sync-ok');
    }catch(e){setSyncStatus('Ошибка синхронизации','sync-error');toast(e.message,'error');}
    finally{saving=false;if(saveAgain){saveAgain=false;queueSave();}}
  }
  async function refreshWorkbook(showToast=false){
    try{
      const response=await fetch('/api/bootstrap',{cache:'no-store'});const data=await response.json();
      if(!response.ok)throw new Error(data.error||'Не удалось перечитать Excel');
      if(data.revision!==state.revision||(data.appRevision||'')!==state.appRevision){
        loadData(data.sheets,data.name,data.revision,data.appState,data.appRevision);
        setSyncStatus('Обновлено из Excel','sync-ok');
        if(showToast)toast('Данные обновлены из рабочей книги Excel.');
      }
      return true;
    }catch(e){setSyncStatus('Нет связи с сервером','sync-error');if(showToast)toast(e.message,'error');return false;}
  }
  async function pollWorkbook(){
    if(polling||saving||saveTimer)return;polling=true;
    try{
      const response=await fetch('/api/revision',{cache:'no-store'});if(!response.ok)return;
      const info=await response.json();if((info.revision&&info.revision!==state.revision)||(info.appRevision||'')!==state.appRevision)await refreshWorkbook(true);
    }catch(_){setSyncStatus('Нет связи с сервером','sync-error');}
    finally{polling=false;}
  }
  function toast(msg,type=''){const el=document.createElement('div');el.className='toast '+type;el.textContent=msg;$('#toastRoot').appendChild(el);setTimeout(()=>el.remove(),3400);}
  function badgeStatus(a){
    if(requiresClarification(a))return '<span class="status status-clarify">Нужно уточнить</span>';
    if(a.workId){const w=state.works.find(x=>x.id===a.workId);return w?`<span class="status ${statusClass(w.status)}">${esc(statusLabel(w.status))}</span>`:'<span class="status status-clarify">Без работы</span>';}
    return '';
  }
  function workTitle(w){const rooms=(w.rooms||[]).join(', ')||w.location||'Помещение не указано';return `${rooms} · ${w.description}`;}
  function issueFor(a){return a.aiSummary||a.issue||shortIssue(a.category);}
  function getAppealWork(a){return state.works.find(w=>w.id===a.workId)||null;}
  function calcGroups(){return state.works.filter(w=>w.appealIds.length>0).length;}
  function workCard(w){const linked=state.appeals.filter(a=>w.appealIds.includes(a.id));const clar=linked.filter(requiresClarification).length;const loc=(w.rooms||[]).map(r=>roomInputValue(r,w.building)).join(', ')||roomInputValue(w.location,w.building);return `<div class="work-row" data-work="${esc(w.id)}"><div class="work-code">${esc(displayWorkId(w.id))}</div><div class="work-info"><div class="work-name">${esc(loc)} · ${esc(problemTitleForWork(w))}</div><div class="work-meta"><span>${esc(w.building?'Корпус '+w.building:'Корпус не указан')}</span><span>·</span><span>Зона обслуживания ${esc(w.zone||'не указана')}</span><span>·</span><span>${linked.length} сообщ.</span><span>·</span><span>${esc(w.executor||'Не назначен')}</span>${w.source==='pilot'?'<span>·</span><span class="success-text">Новая работа</span>':''}</div></div><div class="work-end"><span class="status ${statusClass(w.status)}">${esc(w.status)}</span>${clar?`<span class="count-meta">${clar} уточнить</span>`:''}</div></div>`;}
  function attentionItems(){
    return sortedAppeals(state.appeals.filter(requiresClarification)).map(a=>{
      const reason=clarificationReasonText(a);
      const place=[appealBuilding(a)?'Корпус '+appealBuilding(a):'',roomInputValue(appealRoom(a),appealBuilding(a))].filter(Boolean).join(' · ');
      return {id:a.id,title:`${a.id} · ${reason||'требуется уточнение'}`,text:`${a.issue||shortIssue(a.category)}${place?' · '+place:''}`};
    });
  }
  function extractTenantQuestion(a){
    const text=String(a?.text||'').trim();if(!text)return '';
    const explicit=text.match(/[^.!?\n]*\?+/g);
    if(explicit?.length)return explicit.map(x=>x.trim()).filter(Boolean).join(' ');
    const sentences=text.split(/(?<=[.!])\s+/);
    const request=sentences.find(x=>/(когда\s+(придут|при[йд]ет|ждать|ожидать|будет)|кто\s+(придет|придёт|ответствен)|почему\s+(не|так)|можно\s+ли|подскажите|просим\s+(сообщить|уточнить)|сообщите\s*,?\s*пожалуйста|жд[её]м\s+новост|хотим\s+узнать|интересует\s+статус)/i.test(x));
    if(request){
      if(/жд[её]м\s+новост/i.test(request))return 'Просит сообщить новости о ходе общей проверки.';
      return request.trim();
    }
    return '';
  }
  function questionInfo(a){
    const stored=state.appState?.tenantQuestions?.[a.id]||{};
    const text=String(stored.text||extractTenantQuestion(a)).trim();
    if(!text)return null;
    return {text,answered:stored.answered===true};
  }
  function groupQuestionInfo(group){
    const questions=group.appeals.map(a=>({appeal:a,question:questionInfo(a)})).filter(x=>x.question);
    const unanswered=questions.filter(x=>!x.question.answered);
    return {questions,unanswered,hasUnanswered:unanswered.length>0};
  }
  function markTenantQuestionAnswered(id,answered=true,feedback=null){
    const a=state.appeals.find(x=>x.id===id);if(!a)return;
    const info=questionInfo(a);if(!info)return;
    state.appState.tenantQuestions=state.appState.tenantQuestions||{};
    state.appState.tenantQuestions[id]={text:info.text,answered:!!answered,updatedAt:new Date().toISOString()};
    addHistory(id,answered?'Вопрос арендатора отмечен как отвеченный.':'Вопрос арендатора снова отмечен как ожидающий ответа.');
    queueSave();
    render();
    toast(feedback||(answered?'Вопрос отмечен как отвеченный':'Вопрос снова ожидает ответа'));
  }
  function appealCountWord(n){const m=n%100; if(m>=11&&m<=14)return 'обращений'; const d=n%10; return d===1?'обращение':(d>=2&&d<=4?'обращения':'обращений');}
  function problemGroups(){
    const groups=new Map();
    state.appeals.forEach(a=>{
      const ownWork=getAppealWork(a);
      const parent=a.duplicateOf?state.appeals.find(x=>x.id===a.duplicateOf):null;
      const parentWork=parent?getAppealWork(parent):null;
      const work=ownWork||parentWork;
      const building=(a.building||work?.building||parent?.building||'').toUpperCase();
      const room=norm(roomInputValue(a.room||work?.location||parent?.room||'',building));
      const zone=norm(a.zone||work?.zone||parent?.zone||'');
      const category=norm(a.category||categoryOf(a.text||''));
      const placeKey=category==='температура'&&zone?('zone-'+zone):(room?('room-'+room):(zone?('zone-'+zone):''));
      let key;
      if(work) key='work:'+work.id;
      else if(parent) key='appeal:'+(parent.duplicateOf||parent.id);
      else if(placeKey) key=['place',building,placeKey,category,requiresClarification(a)?'clarify':'queue'].join(':');
      else key='appeal:'+a.id;
      if(!groups.has(key))groups.set(key,{key,work,appeals:[]});
      const bucket=groups.get(key);if(!bucket.work&&work)bucket.work=work;
      bucket.appeals.push(a);
    });
    const grouped=[...groups.values()].map(g=>{
      const items=sortedAppeals(g.appeals);
      const latest=items[0];
      const work=g.work||getAppealWork(latest);
      const building=work?.building||latest.building||'';
      const room=(work?.rooms||[]).filter(Boolean).map(r=>roomInputValue(r,building)).join(', ')||roomInputValue(work?.location||latest.room||'',building);
      const zone=work?.zone||latest.zone||state.spaces.find(sp=>sp.building===building&&sp.room===latest.room)?.zone||'';
      const issue=work?problemTitleForWork(work):fallbackProblemTitle(latest.issue||shortIssue(latest.category));
      const status=work?.status||(g.appeals.some(requiresClarification)?'нужно уточнить':'без работы');
      const unassigned=!work;
      const questions=groupQuestionInfo({...g,appeals:items});
      return { ...g, appeals:items, latest, work, building, room, zone, issue, status, unassigned, updated:appealDateValue(latest.time), category:work?.category||latest.category, questions, hasUnansweredQuestion:questions.hasUnanswered };
    });
    // Самостоятельные проблемы, созданные диспетчером, хранятся как строки листа «Работы» без искусственного обращения арендатора.
    const representedWorkIds=new Set(grouped.map(g=>g.work?.id).filter(Boolean));
    const standalone=state.works.filter(w=>!representedWorkIds.has(w.id)&&!state.appeals.some(a=>a.workId===w.id)&&isManagementCompanyOwner(ownerForWork(w)))
      .map(work=>{
        const building=work.building||'';
        const rooms=(work.rooms||[]).filter(Boolean).map(r=>roomInputValue(r,building));
        const room=rooms.join(', ')||roomInputValue(work.location||'',building);
        const space=state.spaces.find(sp=>building&&sp.building.toUpperCase()===String(building).toUpperCase()&&roomInputValue(sp.room,building)===roomInputValue(room,building));
        const zone=work.zone||space?.zone||'';
        const updated=appealDateValue(work.updated);
        return {key:'work:'+work.id,work,appeals:[],latest:null,building,room,zone,issue:problemTitleForWork(work),status:work.status||'открыто',unassigned:false,updated,category:work.category||categoryOf(work.description||''),questions:{questions:[],unanswered:[],hasUnanswered:false},hasUnansweredQuestion:false,standalone:true};
      });
    return [...grouped,...standalone].sort((a,b)=>Number(b.hasUnansweredQuestion)-Number(a.hasUnansweredQuestion)||b.updated-a.updated);
  }
  function groupMatchesFilter(group,filter){
    if(filter==='status-accepted')return !!group.work&&norm(group.status)==='принято';
    if(filter==='status-open')return !!group.work&&norm(group.status)==='открыто';
    if(filter==='status-progress')return !!group.work&&norm(group.status)==='в работе';
    return true;
  }
  function problemCard(group){
    const linked=group.appeals.length;
    const questionMark=group.hasUnansweredQuestion?`<span class="question-alert question-alert-feed" title="Есть вопрос арендатора без ответа">!</span>`:'';
    // В лентах обзора и решённых проблем показываем только корпус и помещение.
    const place=[group.building?'Корпус '+group.building:'',group.room?'Помещение '+roomInputValue(group.room,group.building):''].filter(Boolean).join(' · ')||'Место уточняется';
    const target=group.latest?.id?`data-appeal="${esc(group.latest.id)}"`:`data-problem-work="${esc(group.work?.id||'')}"`;
    const countText=linked?`${linked} ${appealCountWord(linked)}`:'Создана диспетчером';
    const timeText=group.latest?.time||group.work?.updated||'';
    const workPrefix=group.work?`<span class="problem-card-work-id">${esc(displayWorkId(group.work.id))}</span>`:'';
    return `<button type="button" class="problem-card" ${target}>
      <span class="problem-main"><span class="problem-title">${questionMark}${workPrefix}${esc(group.issue)}</span><span class="problem-meta"><span>${esc(place)}</span><span>${esc(countText)}</span>${timeText?`<span>Обновлено: ${esc(timeText)}</span>`:''}</span></span>
    </button>`;
  }
  function statusAppealCount(status){return problemGroups().filter(g=>g.work&&norm(g.status)===norm(status)).length;}
  function overviewView(){
    const groups=problemGroups().filter(g=>!isResolvedGroup(g)&&!g.appeals.some(requiresClarification));
    const defs=[
      {label:'Открыто',filter:'status-open',cls:'kpi-open',match:g=>g.work&&norm(g.status)==='открыто'},
      {label:'Принято',filter:'status-accepted',cls:'kpi-accepted',match:g=>g.work&&norm(g.status)==='принято'},
      {label:'В работе',filter:'status-progress',cls:'kpi-progress',match:g=>g.work&&norm(g.status)==='в работе'}
    ];
    const cards=defs.map(d=>{const matched=groups.filter(d.match);return {...d,value:matched.length,hasQuestions:matched.some(g=>g.hasUnansweredQuestion)};});
    const filterLabels={'all':'Все проблемы','status-open':'Открыто','status-accepted':'Принято','status-progress':'В работе'};
    const visibleGroups=groups.filter(g=>groupMatchesFilter(g,state.filter)).sort((a,b)=>Number(b.hasUnansweredQuestion)-Number(a.hasUnansweredQuestion)||b.updated-a.updated);
    return `<div class="page-heading"><div><h1 class="page-title">Обзор</h1></div><div class="heading-actions"><button class="btn btn-primary" id="quickNewBtn">＋ Обращение</button></div></div>
      <div class="kpi-grid status-kpi-grid">${cards.map(c=>`<button type="button" class="kpi-card ${c.cls} ${state.filter===c.filter?'is-active':''}" data-kpi-filter="${c.filter}" aria-pressed="${state.filter===c.filter}" aria-label="Показать проблемы: ${c.label}"><span class="kpi-top"><span>${c.label}</span>${c.hasQuestions?'<span class="kpi-question-mark" title="Есть вопросы арендаторов без ответа">!</span>':''}</span><span class="kpi-value">${c.value}</span></button>`).join('')}</div>
      <section class="panel overview-panel overview-problems-panel"><div class="panel-head"><div><h2 class="panel-title">Проблемы</h2><div class="panel-hint">${visibleGroups.length} · ${esc(filterLabels[state.filter]||'Все проблемы')}${visibleGroups.some(g=>g.hasUnansweredQuestion)?' · сначала вопросы без ответа':''}</div></div></div>
        <div class="overview-scroll-list problem-list">${visibleGroups.length?visibleGroups.map(problemCard).join(''):'<div class="empty-state">Нет проблем по выбранному фильтру</div>'}</div>
      </section>`;
  }
  function resolvedProblemsView(){
    const groups=problemGroups().filter(isResolvedGroup).sort((a,b)=>b.updated-a.updated);
    return `<div class="page-heading"><div><h1 class="page-title">Решённые проблемы</h1><p class="page-subtitle">Проблемы с закрытыми работами</p></div></div>
      <section class="panel overview-panel overview-problems-panel"><div class="panel-head"><div><h2 class="panel-title">Решённые проблемы</h2><div class="panel-hint">${groups.length} ${appealCountWord(groups.length)}</div></div></div>
        <div class="overview-scroll-list problem-list">${groups.length?groups.map(problemCard).join(''):'<div class="empty-state"><strong>Пока нет решённых проблем</strong>Закрытые работы появятся здесь.</div>'}</div>
      </section>`;
  }

  function appealDateValue(value){
    const text=String(value||'').trim();
    if(!text)return 0;
    if(/сейчас|только что|только\s+что/i.test(text))return Number.MAX_SAFE_INTEGER;
    // Поддерживаем даты из Excel (16.11 12:25), полные русские даты
    // (17.11.2026, 20:23) и ISO-строки, не меняя исходное значение.
    const iso=Date.parse(text);
    if(/^\d{4}-\d{2}-\d{2}(?:[T\s]|$)/.test(text)&&Number.isFinite(iso))return iso;
    const m=text.match(/(\d{1,2})[.\-/](\d{1,2})(?:[.\-/](\d{2,4}))?[,\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if(m){
      let year=m[3]?Number(m[3]):new Date().getFullYear();
      if(year<100)year+=2000;
      const stamp=new Date(year,Number(m[2])-1,Number(m[1]),Number(m[4]),Number(m[5]),Number(m[6]||0)).getTime();
      if(Number.isFinite(stamp))return stamp;
    }
    return Number.isFinite(iso)?iso:0;
  }
  function sortedAppeals(items){
    // Стабильная сортировка от новых обращений к старым; исходные объекты и данные не изменяются.
    return items.map((item,index)=>({item,index,time:appealDateValue(item.time)}))
      .sort((a,b)=>b.time-a.time||a.index-b.index)
      .map(entry=>entry.item);
  }
  function sortedWorks(items){
    const direction=state.workSort==='oldest'?1:-1;
    return [...items].sort((a,b)=>direction*(appealDateValue(a.updated)-appealDateValue(b.updated)));
  }
  function appealRow(a,showStatus=false){
    // В ленте используем тот же порядок и визуальную структуру, что и в карточке проблемы:
    // заявитель → исходный текст обращения → дата и канал. Не подменяем текст пересказом.
    const q=questionInfo(a);const questionMark=q&&!q.answered?'<span class="question-alert message-question-alert" title="Вопрос арендатора ожидает ответа">!</span>':'';
    const clarifyLine=showStatus?`<small class="problem-message-clarify-reason">Причина: ${esc(clarificationReasonText(a))}</small>`:'';
    const meta=[a.time||'Время не указано',a.channel||'Канал не указан'].join(' · ');
    return `<button type="button" class="problem-card problem-message-link appeal-feed-card ${showStatus?'clarify-appeal-item':''}" data-appeal-message="${esc(a.id)}"><span class="problem-message-copy"><strong>${questionMark}${esc(a.reporter||'Заявитель не указан')}</strong><span>${esc(a.text||'Сообщение без текста')}</span><small>${esc(meta)}</small>${clarifyLine}</span><span class="problem-arrow" aria-hidden="true">›</span></button>`;
  }
  function appealsView(onlyClarify=false){
    const filtered=state.appeals.filter(a=>{
      if(onlyClarify&&!requiresClarification(a))return false;
      const q=norm(state.query);if(q&&!norm([a.id,a.reporter,a.text,a.building,a.room,a.workId,a.portal,a.channel].join(' ')).includes(q))return false;
      if(!onlyClarify&&state.appealChannelFilter!=='all'&&channelFilterKey(a.channel)!==state.appealChannelFilter)return false;
      if(!onlyClarify){
        const building=appealBuilding(a);
        if(state.appealBuildingFilter==='A'&&building!=='A')return false;
        if(state.appealBuildingFilter==='B'&&building!=='B')return false;
        if(state.appealBuildingFilter==='missing'&&building)return false;
      }
      return true;
    });
    const list=sortedAppeals(filtered); // По умолчанию новые обращения показываются выше старых.
    const title=onlyClarify?'Нужно уточнить':'Входящие';
    return `<div class="page-heading"><div><h1 class="page-title">${title}</h1></div><div class="heading-actions"><button class="btn btn-primary" id="quickNewBtn">＋ Обращение</button></div></div>
      <div class="table-toolbar"><div class="searchbox"><span>⌕</span><input id="appealSearch" placeholder="Поиск по месту или неисправности" value="${esc(state.query)}"></div>${onlyClarify?'':`<select id="appealChannelFilter" class="filter-select" aria-label="Фильтр по каналу"><option value="all" ${state.appealChannelFilter==='all'?'selected':''}>Все каналы</option><option value="portal" ${state.appealChannelFilter==='portal'?'selected':''}>Портал</option><option value="email" ${state.appealChannelFilter==='email'?'selected':''}>Почта</option><option value="desk-a" ${state.appealChannelFilter==='desk-a'?'selected':''}>Стойка регистрации · корпус A</option><option value="desk-b" ${state.appealChannelFilter==='desk-b'?'selected':''}>Стойка регистрации · корпус B</option><option value="desk-phone" ${state.appealChannelFilter==='desk-phone'?'selected':''}>Общий телефон стойки регистрации</option><option value="missing" ${state.appealChannelFilter==='missing'?'selected':''}>Канал не указан</option></select><select id="appealBuildingFilter" class="filter-select" aria-label="Фильтр по корпусу"><option value="all" ${state.appealBuildingFilter==='all'?'selected':''}>Все корпуса</option><option value="A" ${state.appealBuildingFilter==='A'?'selected':''}>Корпус A</option><option value="B" ${state.appealBuildingFilter==='B'?'selected':''}>Корпус B</option><option value="missing" ${state.appealBuildingFilter==='missing'?'selected':''}>Корпус не указан</option></select>`}<span class="list-count">${list.length}</span></div>
      <div class="appeal-list">${list.length?list.map(a=>appealRow(a,onlyClarify)).join(''):'<div class="empty-state"><strong>Ничего не найдено</strong>Измените фильтры или запрос</div>'}</div>`;
  }
  function worksView(){
    const q=norm(state.query);
    const works=sortedWorks(state.works.filter(w=>
      (!q||norm([w.id,w.location,w.description,w.building,w.zone,w.executor].join(' ')).includes(q))&&
      (state.workStatusFilter==='all'||norm(w.status)===norm(state.workStatusFilter))
    ));
    return `<div class="page-heading"><div><h1 class="page-title">Работы</h1></div><div class="heading-actions"><button class="btn btn-light" id="downloadCsvBtn">↓ Выгрузить список</button></div></div>
      <div class="table-toolbar"><div class="searchbox"><span>⌕</span><input id="workSearch" placeholder="Поиск по работе, комнате или исполнителю" value="${esc(state.query)}"></div>
      <select id="workFilter" class="filter-select"><option value="all" ${state.workStatusFilter==='all'?'selected':''}>Все статусы</option><option value="открыто" ${state.workStatusFilter==='открыто'?'selected':''}>Открыто</option><option value="принято" ${state.workStatusFilter==='принято'?'selected':''}>Принято</option><option value="в работе" ${state.workStatusFilter==='в работе'?'selected':''}>В работе</option><option value="закрыто" ${state.workStatusFilter==='закрыто'?'selected':''}>Закрыто</option></select>
      <select id="workSort" class="filter-select" aria-label="Сортировка работ"><option value="newest" ${state.workSort==='newest'?'selected':''}>Сначала обновлённые</option><option value="oldest" ${state.workSort==='oldest'?'selected':''}>Сначала давно обновлённые</option></select></div>
      <div class="appeal-list" id="workList">${works.map(w=>`<button type="button" class="problem-card work-feed-card" data-work="${esc(w.id)}"><span class="problem-main"><span class="problem-title">${esc(displayWorkId(w.id))} · ${esc(problemTitleForWork(w))}</span><span class="problem-meta"><span>${esc(w.location||w.rooms?.join(', ')||'Помещение не указано')}</span><span>Корпус ${esc(w.building||'—')}</span><span>Зона ${esc(w.zone||'не указана')}</span><span>${w.appealIds.length} сообщ.</span><span>${esc(w.updated||'Время не указано')}</span></span></span><span class="status ${statusClass(w.status)}">${esc(statusLabel(w.status))}</span></button>`).join('')||'<div class="empty-state">Работы не найдены</div>'}</div>`;
  }
  function spacesView(){return `<section class="panel reference-panel"><div class="reference-table-scroll"><table class="reference-table spaces-reference-table"><thead><tr><th>Корпус</th><th>Помещение</th><th>Как ещё называют</th><th>Этаж</th><th>Зона обслуживания</th><th>Арендатор</th><th>Кто обслуживает</th></tr></thead><tbody>${state.spaces.map(s=>`<tr><td>${esc(s.building)}</td><td>${esc(s.room)}</td><td>${esc(s.alias)}</td><td>${esc(s.floor)}</td><td>${esc(s.zone)}</td><td>${esc(s.tenant)}</td><td>${esc(s.owner)}</td></tr>`).join('')}</tbody></table></div></section>`;}
  function rulesView(){return `<section class="panel reference-panel"><div class="reference-table-scroll"><table class="reference-table rules-reference-table"><thead><tr><th>№</th><th>Тема</th><th>Правило</th></tr></thead><tbody>${state.rules.map(r=>`<tr><td>${esc(r.id)}</td><td>${esc(r.topic)}</td><td>${esc(r.text)}</td></tr>`).join('')}</tbody></table></div></section>`;}
  function render(){
    const node=$('#view');
    if(!node)return;
    try{
      if(state.view==='overview')node.innerHTML=overviewView();
      else if(state.view==='appeals')node.innerHTML=appealsView(false);
      else if(state.view==='clarify')node.innerHTML=appealsView(true);
      else if(state.view==='resolved')node.innerHTML=resolvedProblemsView();
      else if(state.view==='spaces')node.innerHTML=spacesView();
      else if(state.view==='rules')node.innerHTML=rulesView();
      else node.innerHTML=overviewView();
      $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===state.view));
      if(state.selectedAppeal||state.selectedProblemWork)renderProblemDetail();
      if(state.selectedWork)openWorkDetail(state.selectedWork);
      if(state.selectedMessage)renderTenantMessageDetail();
    }catch(error){
      console.error('Ошибка отображения интерфейса:',error);
      node.innerHTML=`<section class="panel" style="max-width:900px;margin:36px auto;padding:28px;border:1px solid #f0c7c7"><h2 style="margin:0 0 10px;color:#a83232">Не удалось отобразить страницу</h2><p style="margin:0 0 12px;color:#536372">Произошла ошибка интерфейса. Перезагрузите приложение. Если ошибка повторится, отправьте технические сведения разработчику.</p><pre style="white-space:pre-wrap;overflow-wrap:anywhere;background:#fff5f5;padding:12px;border-radius:8px;color:#8f2c2c">${esc(error?.message||error)}</pre><button class="btn btn-primary" onclick="location.reload()">Перезагрузить приложение</button></section>`;
    }
  }
  function showStartupError(error){
    console.error('Ошибка запуска приложения:',error);
    const node=$('#view');
    if(node)node.innerHTML=`<section class="panel" style="max-width:900px;margin:36px auto;padding:28px;border:1px solid #f0c7c7"><h2 style="margin:0 0 10px;color:#a83232">Не удалось запустить Диспетчерскую</h2><p style="margin:0 0 12px;color:#536372">Проверьте рабочую книгу Excel в папке data и перезапустите приложение.</p><pre style="white-space:pre-wrap;overflow-wrap:anywhere;background:#fff5f5;padding:12px;border-radius:8px;color:#8f2c2c">${esc(error?.message||error)}</pre><button class="btn btn-primary" onclick="location.reload()">Повторить запуск</button></section>`;
    setSyncStatus('Ошибка запуска','sync-error');
  }
  function go(view){state.view=view;state.selectedAppeal=null;state.selectedProblemWork=null;state.selectedMessage=null;state.selectedWork=null;$('#overlayRoot').innerHTML='';state.query='';state.filter='all';if(view==='appeals'||view==='clarify'){state.appealChannelFilter='all';state.appealBuildingFilter='all';}render();}

  // Main problem card: not an individual tenant message. The linked messages
  // open as a second dialog above this one.
  function openAppeal(id){
    const a=state.appeals.find(x=>x.id===id);if(!a)return;
    state.selectedAppeal=id;state.selectedProblemWork=null;state.selectedMessage=null;state.selectedWork=null;renderProblemDetail();
  }
  function openProblemWork(id){
    const w=state.works.find(x=>x.id===id);if(!w)return;
    state.selectedAppeal=null;state.selectedProblemWork=id;state.selectedMessage=null;state.selectedWork=null;renderProblemDetail();
  }
  function closeAppealDetail(){state.selectedAppeal=null;state.selectedProblemWork=null;state.selectedMessage=null;state.selectedWork=null;$('#overlayRoot').innerHTML='';}
  function closeTenantMessage(){state.selectedMessage=null;const child=$('#tenantMessageOverlay');if(child)child.remove();}
  function workContext(w,group=null){
    const rawLocation=String(w.location||'').trim();
    const ids=(w.rooms&&w.rooms.length?w.rooms:roomList(rawLocation));
    const buildingHint=String(w.building||group?.building||'').toUpperCase();
    let space=null;
    if(ids.length)space=state.spaces.find(s=>norm(s.room)===norm(ids[0])&&(!buildingHint||s.building.toUpperCase()===buildingHint))||null;
    if(!space&&rawLocation)space=state.spaces.find(s=>norm(s.room)===norm(rawLocation)&&(!buildingHint||s.building.toUpperCase()===buildingHint))||null;
    // В старой книге в поле «Помещение или зона» иногда хранится именно зона.
    // В таком случае помещение берём из связанной проблемы, а зону — из справочника.
    const locationIsZone=!!rawLocation&&state.spaces.some(s=>norm(s.zone)===norm(rawLocation)&&(!buildingHint||s.building.toUpperCase()===buildingHint));
    const zoneSpace=locationIsZone?state.spaces.find(s=>norm(s.zone)===norm(rawLocation)&&(!buildingHint||s.building.toUpperCase()===buildingHint)):null;
    if(!space&&group?.room)space=state.spaces.find(s=>norm(s.room)===norm(group.room)&&(!buildingHint||s.building.toUpperCase()===buildingHint))||null;
    if(!space&&/холл/i.test(rawLocation))space=state.spaces.find(s=>s.building.toUpperCase()===buildingHint&&/холл/i.test(s.room))||null;
    const building=w.building||space?.building||zoneSpace?.building||group?.building||'';
    const rawRoom=ids.length?ids.map(x=>roomInputValue(x,building)).filter(Boolean).join(', '):(locationIsZone?'':roomInputValue(rawLocation,building));
    const room=rawRoom||roomInputValue(group?.room,building)||roomInputValue(space?.room,building)||'';
    const zone=w.zone||space?.zone||zoneSpace?.zone||group?.zone||'';
    return {building,room,zone,rawLocation};
  }

  function renderProblemDetail(){
    const id=state.selectedAppeal;
    const selectedStandalone=state.selectedProblemWork?state.works.find(x=>x.id===state.selectedProblemWork):null;
    const realAnchor=id?state.appeals.find(x=>x.id===id):null;
    const anchor=realAnchor||(selectedStandalone?{id:'',workId:selectedStandalone.id,building:selectedStandalone.building||'',room:selectedStandalone.location||'',zone:selectedStandalone.zone||'',issue:selectedStandalone.description||shortIssue(selectedStandalone.category||'прочее'),category:selectedStandalone.category||categoryOf(selectedStandalone.description||''),route:''}:null);
    if(!anchor){state.selectedAppeal=null;state.selectedProblemWork=null;$('#overlayRoot').innerHTML='';return;}
    const group=problemGroups().find(g=>selectedStandalone?g.work?.id===selectedStandalone.id:g.appeals.some(x=>x.id===id))||{appeals:realAnchor?[realAnchor]:[],latest:realAnchor,work:selectedStandalone||getAppealWork(anchor),issue:fallbackProblemTitle(anchor.issue||shortIssue(anchor.category)),building:appealBuilding(anchor),room:appealRoom(anchor),zone:anchor.zone||''};
    const w=group.work||getAppealWork(anchor)||null;
    const status=w?`<span class="status ${statusClass(w.status)}">${esc(statusLabel(w.status))}</span>`:'';
    const allQuestions=group.appeals.map(a=>({a,q:questionInfo(a)})).filter(x=>x.q);
    const openQuestions=allQuestions.filter(x=>!x.q.answered);
    const tenantMessages=sortedAppeals(group.appeals);
    const executorChoices=[...new Set(state.works.map(x=>String(x.executor||'').trim()).filter(x=>x&&norm(x)!=='не назначен'))].sort((a,b)=>a.localeCompare(b,'ru'));
    const executorList=`<datalist id="problemExecutorOptions">${executorChoices.map(x=>`<option value="${esc(x)}"></option>`).join('')}</datalist>`;
    const workDetails=w?`<div class="problem-work-details"><div class="problem-work-id">${esc(displayWorkId(w.id))}</div><div class="problem-work-stacked-fields"><div class="problem-work-field"><span>Обновлено</span><strong>${esc(w.updated||'—')}</strong></div></div><div class="problem-work-description-edit"><label for="problemWorkDescriptionInput">Описание работы</label><div class="problem-work-description-controls"><textarea id="problemWorkDescriptionInput" rows="2" spellcheck="true">${esc(w.description||group.issue||'')}</textarea><button type="button" class="btn btn-primary btn-small" id="saveProblemDescriptionBtn">Сохранить</button></div></div><div class="problem-work-executor-edit"><label for="problemWorkExecutorInput">Исполнитель</label><div class="problem-work-executor-controls"><input id="problemWorkExecutorInput" list="problemExecutorOptions" value="${esc(norm(w.executor)==='не назначен'?'':w.executor||'')}" placeholder="Назначить исполнителя"><button type="button" class="btn btn-primary btn-small" id="saveProblemExecutorBtn">Сохранить</button></div>${executorList}</div></div>`:anchor.route==='tenant'?`<div class="plain-note">По справочнику помещение обслуживает: ${esc(anchor.owner||'не указано')}. Работа управляющей компании не создаётся.</div>`:'<div class="plain-note">Работа пока не заведена. Обращения сохранены, заявители не потеряны.</div>';
    const listMarkup=tenantMessages.map(x=>{
      const q=questionInfo(x);const badge=q&&!q.answered?'<span class="question-alert message-question-alert" title="Вопрос ожидает ответа">!</span>':'';
      return `<button type="button" class="problem-message-link" data-tenant-message="${esc(x.id)}"><span class="problem-message-copy"><strong>${badge}${esc(x.reporter||'Заявитель не указан')}</strong><span>${esc(x.text||'Сообщение без текста')}</span><small>${esc(x.time||'Время не указано')} · ${esc(x.channel||'Канал не указан')}</small></span><span class="problem-arrow">›</span></button>`;
    }).join('');
    $('#overlayRoot').innerHTML=`<div class="overlay appeal-detail-overlay" id="appealDetailOverlay"><section class="appeal-detail-modal problem-detail-modal" role="dialog" aria-modal="true" aria-labelledby="appealDetailTitle">
      <div class="appeal-modal-head"><div class="appeal-modal-title"><div class="eyebrow">ПРОБЛЕМА${group.appeals.length?` · ${group.appeals.length} ${appealCountWord(group.appeals.length)}`:' · создана диспетчером'}</div><div class="appeal-modal-id" id="appealDetailTitle">${esc(group.issue||'Неисправность')}</div><div class="detail-place-line">${esc([group.building?'Корпус '+group.building:'',group.room?roomInputValue(group.room,group.building):'',group.zone?'Зона обслуживания '+group.zone:''].filter(Boolean).join(' · ')||'Место уточняется')}</div></div><div class="appeal-modal-actions"><button type="button" class="close-btn appeal-detail-close" id="appealDetailClose" aria-label="Закрыть">×</button></div></div>
      <div class="appeal-detail-body"><div class="detail-workspace problem-workspace"><div class="detail-main">
        ${allQuestions.length?`<section class="detail-card pending-questions-card"><div class="detail-card-head"><span class="detail-card-title">Вопросы арендаторов</span>${openQuestions.length?'<span class="question-alert question-alert-large">!</span>':'<span class="question-answered-pill">На все вопросы ответили</span>'}</div>${allQuestions.map(({a,q})=>`<button type="button" class="pending-question-row ${q.answered?'is-answered':''}" data-tenant-message="${esc(a.id)}"><strong>${!q.answered?'<span class="question-alert message-question-alert">!</span>':''}${esc(a.reporter||'Заявитель')} ${q.answered?'<span class="question-row-answered">Ответ дан</span>':''}</strong><span>${esc(q.text)}</span><small>${esc(a.time||'')}</small></button>`).join('')}</section>`:''}
        <section class="detail-card"><div class="detail-card-head"><span class="detail-card-title">Обращения арендаторов</span><span class="panel-hint">${tenantMessages.length}</span></div><div class="tenant-message-list">${listMarkup||(group.standalone?'<div class="empty-state">По этой проблеме пока нет сообщений арендаторов</div>':'<div class="empty-state">Нет связанных обращений</div>')}</div></section>
      </div><aside class="detail-side problem-work-side">
        <section class="detail-card problem-work-card"><div class="detail-card-head"><span class="detail-card-title">Работы</span>${w?status:''}</div>${workDetails}${!w&&!requiresClarification(anchor)&&group.building&&group.room?'<div class="problem-work-create"><button class="btn btn-primary" id="createWorkFromAppeal">＋ Создать работу</button></div>':''}</section>
      </aside></div></div></section></div>`;
    $('#appealDetailClose').onclick=closeAppealDetail;
    $('#appealDetailOverlay').addEventListener('click',e=>{if(e.target.id==='appealDetailOverlay')closeAppealDetail();});
    if($('#saveProblemDescriptionBtn'))$('#saveProblemDescriptionBtn').onclick=()=>{
      const input=$('#problemWorkDescriptionInput');
      const next=String(input?.value||'').trim();
      const previous=String(w.description||'').trim();
      if(!next){toast('Описание работы не может быть пустым','warn');return;}
      if(previous===next){toast('Описание работы не изменилось');return;}
      w.description=next;
      if(previous!==next&&state.appState?.problemTitles)delete state.appState.problemTitles[w.id];
      w.updated=workStamp();
      const historyAppeal=group.appeals[0]||null;
      if(historyAppeal)addHistory(historyAppeal.id,'Обновлено описание работы '+displayWorkId(w.id)+'.');
      queueSave();updateNav();render();
      toast('Описание работы обновлено и сохранено в Excel');
      if(id)openAppeal(id);else openProblemWork(w.id);
    };
    if($('#saveProblemExecutorBtn'))$('#saveProblemExecutorBtn').onclick=()=>{
      const input=$('#problemWorkExecutorInput');
      const next=String(input?.value||'').trim();
      const previous=String(w.executor||'Не назначен').trim();
      const normalizedNext=norm(next);
      const assigned=!next||normalizedNext==='не назначен'?'Не назначен':next;
      if(norm(previous)===norm(assigned)){toast('Исполнитель не изменился');return;}
      w.executor=assigned;
      const previousStatus=w.status;
      if(assigned!=='Не назначен'&&['','открыто','без работы'].includes(norm(w.status)))w.status='принято';
      else if(assigned==='Не назначен'&&norm(w.status)==='принято')w.status='открыто';
      const statusChanged=norm(previousStatus)!==norm(w.status);
      if(statusChanged)w.updated=workStamp();
      const logText=`Исполнитель: ${previous} → ${assigned}.${statusChanged?' Статус автоматически изменён: '+previousStatus+' → '+w.status+'.':''}`;
      const historyAppeal=group.appeals[0]||null;
      if(historyAppeal)addHistory(historyAppeal.id,logText);
      queueSave();updateNav();render();
      toast(previousStatus!==w.status?`Исполнитель назначен · статус: ${statusLabel(w.status)}`:'Исполнитель обновлён');
      openAppeal(id);
    };
    if($('#createWorkFromAppeal'))$('#createWorkFromAppeal').onclick=()=>{const created=createManualWork(anchor);if(!created)return;toast(`Создана работа ${displayWorkId(created.id)}`);render();openAppeal(id);};
  }
  function openTenantMessage(id){
    const a=state.appeals.find(x=>x.id===id);if(!a)return;
    state.selectedMessage=id;renderTenantMessageDetail();
  }
  function renderTenantMessageDetail(){
    const id=state.selectedMessage;const a=state.appeals.find(x=>x.id===id);if(!a){state.selectedMessage=null;return;}
    const w=getAppealWork(a);const q=questionInfo(a);const building=appealBuilding(a);const room=appealRoom(a);const zone=a.zone||w?.zone||state.spaces.find(s=>s.building===building&&norm(s.room)===norm(room))?.zone||'';
    const sourceFields=[['№',a.id],['Время',a.time],['Канал',a.channel],...(normalizeChannel(a.channel)==='портал'?[['Номер на портале',a.portal||'Не указан']]:[]),['Заявитель',a.reporter||'Не указан']];
    const contextFields=[['Корпус',building||'Не указан'],['Помещение',roomInputValue(room,building)||'Не указано'],['Зона обслуживания',zone||'Не указана'],['Работа',w?`${displayWorkId(w.id)} · ${problemTitleForWork(w)}`:'Не заведена'],['Статус работы',w?.status||'—']];
    const existing=$('#tenantMessageOverlay');if(existing)existing.remove();
    const child=document.createElement('div');child.className='overlay tenant-message-overlay';child.id='tenantMessageOverlay';child.innerHTML=`<section class="tenant-message-modal" role="dialog" aria-modal="true" aria-labelledby="tenantMessageTitle"><div class="appeal-modal-head"><div class="appeal-modal-title"><div class="eyebrow">СООБЩЕНИЕ АРЕНДАТОРА</div><div class="appeal-modal-id" id="tenantMessageTitle">${esc(a.id)}</div><div class="detail-place-line">${esc(a.reporter||'Заявитель не указан')}</div></div><div class="appeal-modal-actions"><button type="button" class="close-btn" id="tenantMessageClose" aria-label="Закрыть">×</button></div></div><div class="tenant-message-body">
      <section class="detail-card"><div class="detail-card-head"><span class="detail-card-title">Данные из листа «Обращения»</span><div class="two-col-actions"><button class="btn btn-light" id="editTenantMessageBtn">Изменить</button><button class="btn btn-danger btn-small" id="deleteTenantMessageBtn">Удалить обращение</button></div></div><div class="tenant-source-grid">${sourceFields.map(([label,value])=>`<div class="tenant-source-field"><span>${esc(label)}</span><strong>${esc(value||'—')}</strong></div>`).join('')}</div><div class="separator"></div><div class="tenant-raw-text-title">Текст обращения из Excel</div><div class="detail-message tenant-raw-text">${esc(a.text||'Текст обращения не заполнен')}</div></section>
      <section class="detail-card"><div class="detail-card-head"><span class="detail-card-title">Контекст проблемы</span><button class="btn btn-primary btn-small" id="viewProblemFromMessage">Просмотреть проблему ↗</button></div><div class="tenant-source-grid">${contextFields.map(([label,value])=>`<div class="tenant-source-field"><span>${esc(label)}</span><strong>${esc(value||'—')}</strong></div>`).join('')}</div></section>
      ${q?`<section class="detail-card tenant-question-card ${q.answered?'is-answered':''}"><div class="detail-card-head"><span class="detail-card-title">Вопрос арендатора</span>${q.answered?'<span class="question-answered-pill">Ответ дан</span>':'<span class="question-alert">!</span>'}</div><div class="detail-message">${esc(q.text)}</div><div class="two-col-actions" style="margin-top:13px"><button class="btn ${q.answered?'btn-light':'btn-primary'}" id="toggleQuestionAnswered">${q.answered?'Вернуть в ожидающие':'Отметить как отвеченный'}</button></div></section>`:''}
      <section class="detail-card"><div class="detail-card-head"><span class="detail-card-title">Ответ заявителю</span><button class="btn btn-primary" id="generateReplyBtn">✦ Подготовить</button></div><div class="form-field"><textarea id="replyDraftText" rows="8" placeholder="Здесь появится готовый ответ арендатору.">${esc(a.responseDraft||'')}</textarea><div class="form-note reply-generation-note" id="replyGenerationNote">Подготовьте ответ и проверьте адресата и факты перед отправкой.</div></div><div class="two-col-actions" style="margin-top:12px"><button class="btn btn-light" id="saveReplyDraftBtn">Сохранить</button><button class="btn btn-light" id="copyReplyDraftBtn">Копировать</button><button class="btn btn-primary" id="sendReplyBtn">Отправить</button></div><div class="form-note">Кнопка «Отправить» здесь отмечает вопрос как отвеченный; фактическая отправка письма не выполняется.</div></section>
      </div></section>`;
    $('#overlayRoot').appendChild(child);
    $('#tenantMessageClose').onclick=closeTenantMessage;
    child.addEventListener('click',e=>{if(e.target===child)closeTenantMessage();});
    if($('#editTenantMessageBtn'))$('#editTenantMessageBtn').onclick=()=>openAppealForm(a);
    if($('#deleteTenantMessageBtn'))$('#deleteTenantMessageBtn').onclick=()=>deleteAppeal(a.id);
    if($('#viewProblemFromMessage'))$('#viewProblemFromMessage').onclick=()=>{go('overview');openAppeal(a.id);};
    if($('#toggleQuestionAnswered'))$('#toggleQuestionAnswered').onclick=()=>markTenantQuestionAnswered(id,!(q?.answered));
    $('#generateReplyBtn').onclick=()=>generateResidentReply(a);
    $('#saveReplyDraftBtn').onclick=()=>{a.responseDraft=$('#replyDraftText').value.trim();state.appState.tenantMessages=state.appState.tenantMessages||{};state.appState.tenantMessages[id]={...(state.appState.tenantMessages[id]||{}),responseDraft:a.responseDraft};addHistory(id,'Текст ответа заявителю сохранён.');queueSave();toast('Ответ сохранён');};
    $('#copyReplyDraftBtn').onclick=async()=>{const text=$('#replyDraftText').value;if(!text){toast('Сначала подготовьте ответ.','warn');return;}try{await navigator.clipboard.writeText(text);toast('Текст ответа скопирован');}catch(_){$('#replyDraftText').select();document.execCommand('copy');toast('Текст ответа скопирован');}};
    $('#sendReplyBtn').onclick=()=>{const current=questionInfo(state.appeals.find(x=>x.id===id));if(current&&!current.answered){markTenantQuestionAnswered(id,true,'Вопрос отмечен как отвеченный. Внешняя отправка не выполняется.');}else{toast('Открытого вопроса нет. Фактическая отправка не подключена.','warn');}};
  }
  function deleteAppeal(id){
    const appeal=state.appeals.find(x=>x.id===id);
    if(!appeal)return;
    const duplicateDescendants=()=>{
      const related=new Set([id]);let changed=true;
      while(changed){
        changed=false;
        state.appeals.forEach(x=>{if(x.id!==id&&x.duplicateOf&&related.has(x.duplicateOf)&&!related.has(x.id)){related.add(x.id);changed=true;}});
      }
      related.delete(id);return [...related];
    };
    const duplicateIds=duplicateDescendants();
    const containingGroup=problemGroups().find(g=>g.appeals.some(x=>x.id===id));
    const groupAppealIds=(containingGroup?.appeals||[]).filter(x=>x.id!==id).map(x=>x.id);
    const touchedWorkIds=new Set([appeal.workId,...state.works.filter(w=>(w.appealIds||[]).includes(id)).map(w=>w.id),containingGroup?.work?.id].filter(Boolean));
    const touchedWorks=state.works.filter(w=>touchedWorkIds.has(w.id));
    const workRemovalPreview=touchedWorks.filter(w=>{
      const remaining=new Set([
        ...(w.appealIds||[]).filter(appealId=>appealId!==id&&state.appeals.some(x=>x.id===appealId)),
        ...state.appeals.filter(x=>x.id!==id&&x.workId===w.id).map(x=>x.id),
        ...(containingGroup?.work?.id===w.id?groupAppealIds:[]),
        ...duplicateIds.filter(duplicateId=>{const child=state.appeals.find(x=>x.id===duplicateId);return child&&(!child.workId||child.workId===w.id);})
      ]);
      return remaining.size===0;
    });
    const workWarning=workRemovalPreview.length
      ?'\n\nПоскольку это последнее обращение по '+workRemovalPreview.map(w=>displayWorkId(w.id)).join(', ')+', соответствующая проблема и работа также будут удалены из обзора и Excel.'
      :'\n\nСвязанные проблемы и работы с другими обращениями останутся.';
    if(!confirm(`Удалить обращение ${id}? Это действие удалит запись из рабочей книги Excel.${workWarning}\n\nПродолжить?`))return;

    // Remove the appeal first, then rebuild links for every work it touched.
    state.appeals=state.appeals.filter(x=>x.id!==id);
    const removedWorkIds=[];
    for(const work of touchedWorks){
      const survivingDuplicateIds=duplicateIds.filter(duplicateId=>{
        const child=state.appeals.find(x=>x.id===duplicateId);
        return child&&(!child.workId||child.workId===work.id);
      });
      const remainingIds=[...new Set([
        ...(work.appealIds||[]).filter(appealId=>appealId!==id&&state.appeals.some(x=>x.id===appealId)),
        ...state.appeals.filter(x=>x.workId===work.id).map(x=>x.id),
        ...(containingGroup?.work?.id===work.id?groupAppealIds:[]),
        ...survivingDuplicateIds
      ])];
      work.appealIds=remainingIds;
      const promoteIds=[...new Set([
        ...survivingDuplicateIds,
        ...(containingGroup?.work?.id===work.id?groupAppealIds:[])
      ])];
      promoteIds.forEach(relatedId=>{
        const child=state.appeals.find(x=>x.id===relatedId);
        if(child&&!child.workId){child.workId=work.id;child.manualUnlinked=false;child.linkReason='Сохранена связь с проблемой после удаления связанного обращения.';}
      });
      if(!remainingIds.length)removedWorkIds.push(work.id);
    }
    if(removedWorkIds.length){
      const removedSet=new Set(removedWorkIds);
      state.works=state.works.filter(w=>!removedSet.has(w.id));
      state.appState.problemTitles=state.appState.problemTitles||{};
      removedWorkIds.forEach(workId=>delete state.appState.problemTitles[workId]);
      // Defensive cleanup if an old workbook had a one-sided link.
      state.appeals.forEach(x=>{
        if(removedSet.has(x.workId)){
          x.workId='';x.duplicateOf='';x.manualUnlinked=true;
          x.linkReason='Связанная работа удалена после удаления последнего обращения.';
        }
      });
    }
    // Remove metadata and references that belong to the deleted appeal.
    ['tenantQuestions','tenantMessages','aiRouting'].forEach(key=>{
      if(state.appState[key]&&typeof state.appState[key]==='object')delete state.appState[key][id];
    });
    state.appeals.forEach(x=>{if(x.duplicateOf===id)x.duplicateOf='';});
    state.history=state.history.filter(item=>item.appealId!==id);

    state.selectedMessage=null;state.selectedAppeal=null;state.selectedProblemWork=null;state.selectedWork=null;
    $('#overlayRoot').innerHTML='';
    updateNav();queueSave();render();
    const suffix=removedWorkIds.length?` Вместе с последним обращением удалены: ${removedWorkIds.map(displayWorkId).join(', ')}.`:'';
    toast(`Обращение ${id} удалено.${suffix}`);
  }

  function closeOverlay(){
    const workEdit=$('#workEditOverlay');if(workEdit){workEdit.remove();return;}
    if(state.selectedMessage){closeTenantMessage();return;}
    const workDetail=$('#workDetailOverlay');if(workDetail){workDetail.remove();state.selectedWork=null;return;}
    if(state.selectedAppeal||state.selectedProblemWork){closeAppealDetail();return;}
    $('#overlayRoot').innerHTML='';
  }
  function closeFormModal(){if(state.selectedAppeal||state.selectedProblemWork){renderProblemDetail();if(state.selectedMessage)renderTenantMessageDetail();}else{$('#overlayRoot').innerHTML='';}}
  function workStamp(date=new Date()){
    return date.toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
  }
  function addHistory(appealId,text){const time=new Date().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});state.history.push({appealId,text,time});const a=state.appeals.find(x=>x.id===appealId);if(a)a.changeLog=[a.changeLog,time+' · '+text].filter(Boolean).join('\n');queueSave();}
  function moveAppeal(id,targetId){
    const a=state.appeals.find(x=>x.id===id);if(!a)return;
    const old=a.workId;
    if(targetId){
      if(targetId===a.workId){toast('Обращение уже связано с этой работой.');return;}
      const w=state.works.find(x=>x.id===targetId);if(!w){toast('Работа не найдена.','error');return;}
      const owner=ownerForWork(w);
      if(!isManagementCompanyOwner(owner)){
        sendAppealToClarification(a,{building:w.building||a.building,room:clarificationRoomForWork(w),owner,force:true,reason:'Выбранная работа содержит помещение, обслуживание которого не подтверждено управляющей компанией.'});
        updateNav();queueSave();render();toast('Обращение перемещено в «Нужно уточнить».','warn');return;
      }
      unlinkAppeal(a);
      w.appealIds.push(id);a.workId=targetId;a.manualUnlinked=false;a.route='';
      a.building=w.building||a.building||'';a.room=(w.rooms||[]).find(Boolean)||w.location||a.room||'';a.zone=w.zone||a.zone||'';a.owner=owner;
      a.missing=(a.missing||[]).filter(x=>!/(корпус|помещен|обслуживающ)/i.test(x));a.needsClarification=requiresClarification(a);a.linkReason='Перемещено диспетчером';
      addHistory(id,`Перенесено из ${displayWorkId(old)||'очереди'} в ${displayWorkId(targetId)}.`);
    }else{
      unlinkAppeal(a);
      a.manualUnlinked=true;a.needsClarification=requiresClarification(a);addHistory(id,`Снята привязка к работе ${displayWorkId(old)}.`);
    }
    updateNav();queueSave();toast(targetId?`Входящее перенесено в ${displayWorkId(targetId)}`:'Обращение оставлено без работы');render();openTenantMessage(id);
  }
  function nextWorkId(){const nums=state.works.map(w=>Number((String(w.id||'').match(/(\d+)$/)||[])[1]||0));return 'Р-'+String(Math.max(0,...nums)+1).padStart(2,'0');}
  function createManualWork(a){if(requiresClarification(a)){a.needsClarification=true;toast('Работу нельзя создать: уточните адрес и подтвердите, что помещение обслуживает управляющая компания.','warn');updateNav();render();return null;}const w={id:nextWorkId(),building:a.building,location:a.room,zone:a.zone||'—',executor:'Не назначен',status:'открыто',updated:workStamp(),description:a.issue||shortIssue(a.category),rooms:[a.room],category:a.category,appealIds:[a.id],source:'pilot',previousWork:'',notes:[]};state.works.push(w);a.workId=w.id;a.manualUnlinked=false;a.route='';a.missing=(a.missing||[]).filter(x=>!/(корпус|помещен|обслуживающ)/i.test(x));a.needsClarification=requiresClarification(a);addHistory(a.id,`Создана новая работа ${displayWorkId(w.id)}.`);updateNav();queueSave();return w;}
  function openAppealForm(appeal=null){
    const now=new Date();
    const currentAppealTime=`${String(now.getDate()).padStart(2,'0')}.${String(now.getMonth()+1).padStart(2,'0')} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    const a=appeal||{id:'',time:currentAppealTime,channel:'портал',portal:'',reporter:'',text:'',building:'',room:''};
    const editing=!!appeal;
    const channel=normalizeChannel(a.channel);
    const problemKey=g=>'problem:'+(g.work?'work:'+g.work.id:'appeal:'+g.appeals[0].id);
    // По умолчанию даже редактируемое обращение перепроверяется автоматически; ручная связь выбирается отдельно.
    const selectedRelation='auto';
    const problemOptions=problemGroups().map(g=>{
      const key=problemKey(g);const place=[g.building?'корпус '+g.building:'',roomInputValue(g.room,g.building)].filter(Boolean).join(', ')||'место уточняется';
      const workId=g.work?.id||g.appeals.map(x=>getAppealWork(x)?.id).find(Boolean)||'';
      const prefix=workId?displayWorkId(workId):'Без работы';
      return `<option value="${esc(key)}" ${selectedRelation===key?'selected':''}>${esc(prefix)} · ${esc(g.issue)} · ${esc(place)} · ${g.appeals.length} сообщ.</option>`;
    }).join('');
    $('#overlayRoot').innerHTML=`<div class="overlay modal-overlay" id="formOverlay"><div class="modal form-modal"><div class="modal-head"><div><div class="eyebrow">${editing?'РЕДАКТИРОВАНИЕ ОБРАЩЕНИЯ':'НОВОЕ ОБРАЩЕНИЕ'}</div><h3>${editing?'Изменить обращение '+esc(a.id):'Новое обращение'}</h3></div><button class="close-btn" id="formClose">×</button></div><form id="appealForm"><div class="modal-body"><div class="form-grid"><div class="form-field"><label>Заявитель</label><input name="reporter" value="${esc(a.reporter)}" placeholder="Имя или организация"></div><div class="form-field"><label>Канал</label><select name="channel" id="appealChannel">${channel&&!['портал','почта','стойка регистрации корпуса A','стойка регистрации корпуса B','общий телефон стойки регистрации'].includes(channel)?`<option value="${esc(channel)}" selected>${esc(channel)}</option>`:''}<option value="портал" ${channel==='портал'?'selected':''}>Портал</option><option value="почта" ${channel==='почта'?'selected':''}>Почта</option><option value="стойка регистрации корпуса A" ${channel==='стойка регистрации корпуса A'?'selected':''}>Стойка регистрации · корпус A</option><option value="стойка регистрации корпуса B" ${channel==='стойка регистрации корпуса B'?'selected':''}>Стойка регистрации · корпус B</option><option value="общий телефон стойки регистрации" ${channel==='общий телефон стойки регистрации'?'selected':''}>Общий телефон стойки регистрации</option></select></div><div class="form-field"><label>Корпус</label><select name="building"><option value="">Не указан</option><option value="A" ${a.building==='A'?'selected':''}>A</option><option value="B" ${a.building==='B'?'selected':''}>B</option></select></div><div class="form-field"><label>Кабинет / помещение</label><input name="room" value="${esc(roomInputValue(a.room,a.building))}" placeholder="301, переговорная, холл 1 этажа…"></div><div class="form-field" id="portalField" ${channel==='портал'?'':'hidden'}><label>Номер на портале</label><input name="portal" value="${esc(a.portal)}" placeholder="Например, P112"></div><div class="form-field"><label>Время</label><input name="time" value="${esc(a.time)}" placeholder="16.11 12:40"></div><div class="form-field full"><label>Текст обращения</label><textarea name="text" placeholder="Что случилось? Какие детали сообщил заявитель?">${esc(a.text)}</textarea></div><div class="form-field full relation-picker"><label>Связать с проблемой</label><select name="linkTarget" id="linkTarget"><option value="auto" ${selectedRelation==='auto'?'selected':''}>Добавить автоматически</option><option value="">Оставить без работы</option><optgroup label="Проблемы">${problemOptions||'<option disabled>Нет других проблем</option>'}</optgroup></select><span class="relation-help">Обращение сохранится отдельной записью. Система сопоставит его с существующей проблемой или создаст новую, если совпадения нет.</span></div></div><div class="form-note">Укажи текст и известные сведения. Корпус и помещение система дополнительно попробует определить по самому сообщению.</div></div><div class="modal-foot"><button type="button" class="btn btn-light" id="cancelForm">Отмена</button><button type="submit" class="btn btn-primary">${editing?'Сохранить изменения':'Создать обращение'}</button></div></form></div></div>`;
    const togglePortalField=()=>{const visible=$('#appealChannel').value==='портал';$('#portalField').hidden=!visible;};
    $('#appealChannel').addEventListener('change',togglePortalField);togglePortalField();
    $('#formClose').onclick=closeFormModal;$('#cancelForm').onclick=closeFormModal;$('#formOverlay').addEventListener('click',e=>{if(e.target.id==='formOverlay')closeFormModal();});
    $('#appealForm').addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.currentTarget);const obj=Object.fromEntries(fd.entries());obj.channel=normalizeChannel(obj.channel);obj.room=canonicalRoomValue(obj.room,obj.building);obj.portal=obj.channel==='портал'?(obj.portal||''):'';saveAppeal(a,obj,editing);});
  }
  function deriveAppeal(a){
    const text=a.text||'';let sp=spaceForAddress(a.building,a.room,state.spaces);
    if(!sp)sp=getSpaceForText((a.building?'корпус '+a.building+' ':'')+(a.room||'')+' '+text,a.reporter,state.spaces);
    const cat=categoryOf(text);
    const building=a.building||sp?.building||'';const room=a.room||sp?.room||'';
    const owner=sp?.owner||'';
    const missing=[];if(!a.reporter||norm(a.reporter)==='не записан')missing.push('Заявитель / контакт');if(!building)missing.push('Корпус');if(!room)missing.push('Помещение');
    return {...a,building,room,sourceBuilding:a.building||'',sourceRoom:a.room||'',zone:sp?.zone||'',owner,category:cat,issue:shortIssue(cat),workId:a.workId||'',missing,needsClarification:!building||!room||!isManagementCompanyOwner(owner),route:owner&&!isManagementCompanyOwner(owner)?'tenant':''};
  }
  function saveAppeal(old,obj,editing){
    const a=deriveAppeal({...old,...obj});
    if(editing){Object.assign(old,a);}
    else{
      const max=state.appeals.reduce((m,x)=>Math.max(m,Number((x.id.match(/(\d+)$/)||[])[1]||0),0),0);
      a.id='О-'+String(max+1).padStart(2,'0');a.source='manual';a.time=a.time||'сейчас';
      state.appeals.push(a);
    }

    const relation=String(obj.linkTarget||'');
    const legacyAppealId=relation.startsWith('appeal:')?relation.slice(7):'';
    const targetProblemKey=relation.startsWith('problem:')?relation.slice(8):'';
    const targetProblem=targetProblemKey?problemGroups().find(g=>(g.work?'work:'+g.work.id:'appeal:'+g.appeals[0].id)===targetProblemKey):null;
    const target=targetProblem?(targetProblem.appeals.find(x=>x.id!==a.id)||targetProblem.appeals[0]):(legacyAppealId?state.appeals.find(x=>x.id===legacyAppealId):null);
    const targetWork=targetProblem?.work||(target?.workId?state.works.find(w=>w.id===target.workId):null);
    const autoAssign=relation==='auto'||(!relation&&!editing);
    // Сначала снимаем прежнюю привязку, затем добавляем выбранную проблему — так связи не дублируются.
    unlinkAppeal(a,targetWork?.id||'');
    a.manualUnlinked=false;

    if(targetProblem?.work){
      const targetOwner=ownerForWork(targetProblem.work);
      if(!isManagementCompanyOwner(targetOwner)){
        a.manualUnlinked=true;
        a.owner=targetOwner;
        a.route=targetOwner?'tenant':'';
        a.linkReason='Выбранная проблема не подтверждена как обслуживаемая управляющей компанией.';
        if(targetProblem.work.source==='pilot'&&!(targetProblem.work.appealIds||[]).length)state.works=state.works.filter(w=>w.id!==targetProblem.work.id);
      }else{
        const targetMessage=targetProblem.appeals.find(x=>x.id!==a.id)||null;
        if(targetMessage)a.duplicateOf=targetMessage.id;
        a.linkReason='Связано диспетчером с проблемой '+targetProblem.work.id;
        if(!targetProblem.work.appealIds.includes(a.id))targetProblem.work.appealIds.push(a.id);
        a.workId=targetProblem.work.id;
      }
    }else if(target){
      if(target.id!==a.id)a.duplicateOf=target.id;
      a.linkReason='Связано диспетчером с проблемой '+(targetWork?.id||target.id);
      if(targetWork){
        const targetOwner=ownerForWork(targetWork);
        if(isManagementCompanyOwner(targetOwner)){
          if(!targetWork.appealIds.includes(a.id))targetWork.appealIds.push(a.id);
          a.workId=targetWork.id;
        }else{
          a.duplicateOf='';a.manualUnlinked=true;a.owner=targetOwner;a.route=targetOwner?'tenant':'';
          if(targetWork.source==='pilot'&&!(targetWork.appealIds||[]).length)state.works=state.works.filter(w=>w.id!==targetWork.id);
        }
      }else if(target.building&&target.room&&!requiresClarification(target)){
        const sharedWork=createManualWork(target);
        if(sharedWork){if(!sharedWork.appealIds.includes(a.id))sharedWork.appealIds.push(a.id);a.workId=sharedWork.id;}
        else a.manualUnlinked=true;
      }else{a.manualUnlinked=true;if(requiresClarification(target))a.route=target.route||'tenant';}
    }else if(autoAssign){
      if(requiresClarification(a)){a.manualUnlinked=true;}
      else if(a.building&&a.room){
        const candidate=state.works.find(w=>norm(w.status)!=='закрыто'&&(!w.building||String(w.building).toUpperCase()===String(a.building).toUpperCase())&&(a.category==='температура'?a.zone&&w.zone===a.zone&&w.category==='температура':(w.rooms||[]).some(r=>norm(roomInputValue(r,w.building))===norm(roomInputValue(a.room,a.building)))&&w.category===a.category));
        if(candidate&&isManagementCompanyOwner(ownerForWork(candidate))){candidate.appealIds.push(a.id);a.workId=candidate.id;a.linkReason='Автоматически добавлено к '+candidate.id;}
        else createManualWork(a);
      }else a.manualUnlinked=true;
    }else if(editing){
      a.manualUnlinked=true;a.linkReason='';
    }else{
      a.manualUnlinked=true;
    }

    const linkedWork=state.works.find(w=>w.id===a.workId);
    if(linkedWork){
      a.building=a.building||linkedWork.building||'';
      a.room=a.room||(linkedWork.rooms||[]).find(Boolean)||linkedWork.location||'';
      a.zone=a.zone||linkedWork.zone||'';
      a.missing=(a.missing||[]).filter(x=>!/(корпус|помещен)/i.test(x));
    }
    a.owner=ownerForAppeal(a);
    if(requiresClarification(a)){
      if(a.workId||state.works.some(w=>(w.appealIds||[]).includes(a.id)))unlinkAppeal(a);
      a.duplicateOf='';a.manualUnlinked=true;
      a.needsClarification=true;
      a.route=a.owner&&!isManagementCompanyOwner(a.owner)?'tenant':'';
      a.routeText=a.owner?`Обслуживает: ${a.owner}`:'Обслуживающая организация не подтверждена';
    }else{
      a.needsClarification=false;a.route='';a.routeText='';
    }
    if(!requiresClarification(a))a.missing=(a.missing||[]).filter(x=>!/(обслуживающ)/i.test(x));
    if(editing){Object.assign(old,a);addHistory(old.id,'Данные обращения изменены.');}
    updateNav();if(target||targetProblem?.work){addHistory(a.id,'Добавлено в проблему '+displayWorkId(targetWork?.id||targetProblem?.work?.id||target?.id)+'.');}else if(autoAssign&&a.workId){addHistory(a.id,'Автоматически добавлено в проблему '+displayWorkId(a.workId)+'.');}
    queueSave();closeOverlay();toast(editing?'Изменения сохранены':'Обращение создано');
    render();openTenantMessage(a.id);
    if(autoAssign)queueAutoRouting([a]);
  }

  // Облачный ИИ. Новые/изменённые обращения классифицируются только после согласия пользователя.
  // Ответы и сводки вызываются кнопками; локальных моделей, WebGPU и фоновых загрузок нет.
  const GEMINI_CONSENT_KEY = 'kvartal_gemini_cloud_consent_v2';
  let geminiStatusCache = null;

  function hasGeminiConsent(){
    try{return localStorage.getItem(GEMINI_CONSENT_KEY)==='yes';}catch(_){return false;}
  }
  function setGeminiConsent(value){
    try{if(value)localStorage.setItem(GEMINI_CONSENT_KEY,'yes');else localStorage.removeItem(GEMINI_CONSENT_KEY);}catch(_){}
  }
  async function getGeminiStatus(force=false){
    if(geminiStatusCache&&!force)return geminiStatusCache;
    const response=await fetch('/api/ai/status',{cache:'no-store'});
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||'Не удалось проверить настройки Gemini');
    geminiStatusCache=data;return data;
  }
  async function cloudAIRequest(task,context){
    if(!hasGeminiConsent())throw new Error('Сначала подтвердите передачу обезличенного текста в Google в настройках помощника.');
    const response=await fetch('/api/ai/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({task,context,consent:true})});
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||'Не удалось получить ответ Gemini');
    return data.result||{};
  }
  function appealAIContext(a){
    const w=getAppealWork(a);
    return {
      id:a.id, issue:a.issue||shortIssue(a.category||'прочее'), text:a.text||'', category:a.category||'',
      building:a.building||'', room:a.room||'', zone:a.zone||'', route:a.route||'', service_owner:ownerForAppeal(a),
      missing:(a.missing||[]), question:questionInfo(a)?.text||'', time:a.time||'', channel:a.channel||'',
      work_id:w?.id||'', work_status:w?.status||'', work_description:w?.description||'',
      executor_assigned:!!(w?.executor&&norm(w.executor)!=='не назначен')
    };
  }

  // AI-классификация запускается только для новых/изменённых обращений и только после согласия.
  function appealRoutingFingerprint(a){
    return [a?.id||'',a?.time||'',a?.channel||'',a?.reporter||'',a?.text||'',a?.sourceBuilding||a?.building||'',a?.sourceRoom||a?.room||'',a?.owner||'',a?.workId||'',a?.route||''].join('|');
  }
  function routingContext(a){
    const referenced=extractWorkReference(a.text,state.works);
    const rankedWorks=[
      ...(referenced?[referenced]:[]),
      ...state.works.filter(w=>w.id!==referenced?.id&&norm(w.status)!=='закрыто'),
      ...state.works.filter(w=>norm(w.status)==='закрыто')
    ].filter((w,i,arr)=>arr.findIndex(x=>x.id===w.id)===i).slice(0,28);
    return {
      id:a.id,
      text:a.text||'',
      channel:a.channel||'',
      category:a.category||'',
      issue:a.issue||'',
      explicit_building:a.sourceBuilding||'',
      explicit_room:a.sourceRoom||'',
      resolved_building:a.building||'',
      resolved_room:a.room||'',
      service_owner:ownerForAppeal(a),
      explicit_work_reference:referenced?.id||'',
      linked_work_id:a.workId||'',
      known_works:rankedWorks.map(w=>[
        displayWorkId(w.id),w.building||'',(w.rooms||[]).join(', ')||w.location||'',w.zone||'',w.category||'',w.status||'',w.description||''
      ].join(' | ')),
      space_directory:state.spaces.slice(0,60).map(sp=>[
        sp.building||'',sp.room||'',sp.alias||'',sp.zone||'',sp.owner||'не указано'
      ].join(' | ')),
      dispatch_rules:state.rules.slice(0,20).map(r=>[r.topic||'',r.text||''].join(' | '))
    };
  }
  function unlinkAppeal(a,preserveWorkId=''){
    const linked=state.works.filter(w=>w.id===a.workId||(w.appealIds||[]).includes(a.id));
    state.works.forEach(w=>{w.appealIds=(w.appealIds||[]).filter(id=>id!==a.id);});
    const generatedIds=new Set(linked.filter(w=>w.id!==preserveWorkId&&w.source==='pilot'&&!(w.appealIds||[]).length).map(w=>w.id));
    if(generatedIds.size)state.works=state.works.filter(w=>!generatedIds.has(w.id));
    a.workId='';a.duplicateOf='';
  }
  function attachToWork(a,w,reason='Автоматическая классификация Gemini'){
    if(!w)return false;
    const targetOwner=ownerForWork(w);
    if(!isManagementCompanyOwner(targetOwner)){
      sendAppealToClarification(a,{building:w.building||a.building,room:clarificationRoomForWork(w),owner:targetOwner,force:true,reason:'Связь с работой отклонена: обслуживание всех помещений не подтверждено управляющей компанией.'});
      return false;
    }
    a.owner=targetOwner;
    // Повторное подтверждение той же связи не должно удалять временную работу из state.works.
    if(a.workId!==w.id)unlinkAppeal(a);
    a.workId=w.id;a.manualUnlinked=false;a.route='';
    a.building=a.building||w.building||'';
    a.room=a.room||(w.rooms||[]).find(Boolean)||w.location||'';
    a.zone=a.zone||w.zone||'';
    if(norm(a.category)==='прочее'&&w.category){a.category=w.category;a.issue=w.description||shortIssue(w.category);}
    a.missing=(a.missing||[]).filter(x=>!/(корпус|помещен|обслуживающ)/i.test(x));
    a.needsClarification=requiresClarification(a);
    if(!w.appealIds.includes(a.id))w.appealIds.push(a.id);
    a.linkReason=reason;
    return true;
  }
  function createRoutedWork(a,classification){
    const building=String(classification.building||a.building||'').trim().toUpperCase();
    let room=String(classification.room||a.room||'').trim();
    const roomMatch=room.match(/\b([AB])\s*[-–]?\s*(\d{3})\b/i);
    const finalBuilding=building||(roomMatch?roomMatch[1].toUpperCase():'');
    room=canonicalRoomValue(room,finalBuilding);
    if(!finalBuilding||!room)return null;
    const space=spaceForAddress(finalBuilding,room,state.spaces);
    if(!isManagementCompanyOwner(space?.owner||''))return null;
    const description=String(classification.description||a.text||'').trim()||'Требуется осмотр';
    const allowedCategories=['температура','дверь','освещение','электрика','окно','кондиционер','сантехника','пролив на полу','уборка','прочее'];
    const suggestedCategory=norm(classification.category||'');
    const category=allowedCategories.includes(suggestedCategory)?suggestedCategory:(a.category&&a.category!=='прочее'?a.category:categoryOf(description+' '+a.text));
    const candidate=state.works.find(w=>norm(w.status)!=='закрыто'&&isManagementCompanyOwner(ownerForWork(w))&&String(w.building||'').toUpperCase()===finalBuilding&&
      ((w.rooms||[]).some(r=>norm(roomInputValue(r,w.building))===norm(roomInputValue(room,finalBuilding)) )||norm(roomInputValue(w.location,w.building))===norm(roomInputValue(room,finalBuilding)))&&w.category===category);
    if(candidate){
      if(candidate.id===a.workId){
        a.building=finalBuilding;a.room=space?.room||room;a.zone=a.zone||candidate.zone||space?.zone||'';
        a.needsClarification=false;a.missing=(a.missing||[]).filter(x=>!/(корпус|помещен)/i.test(x));
        return candidate;
      }
      attachToWork(a,candidate,'Совпадение помещения и неисправности');return candidate;
    }
    let w=state.works.find(x=>x.id===a.workId&&x.source==='pilot'&&(x.appealIds||[]).length===1&&x.appealIds[0]===a.id);
    if(!w){unlinkAppeal(a);w={id:nextWorkId(),appealIds:[],source:'pilot',previousWork:'',notes:[]};state.works.push(w);}
    Object.assign(w,{building:finalBuilding,location:space?.room||room,rooms:[space?.room||room],zone:String(classification.zone||space?.zone||a.zone||''),executor:'Не назначен',status:'открыто',updated:workStamp(),description,category,space:space||null});
    if(!w.appealIds.includes(a.id))w.appealIds.push(a.id);
    if(classification.title)rememberProblemTitle(w.id,classification.title);
    a.workId=w.id;a.building=finalBuilding;a.room=space?.room||room;a.zone=w.zone;a.owner=space.owner;a.category=category;a.issue=description;a.route='';a.manualUnlinked=false;a.needsClarification=requiresClarification(a);a.missing=(a.missing||[]).filter(x=>!/(корпус|помещен|обслуживающ)/i.test(x));
    addHistory(a.id,'Gemini создала новую работу '+displayWorkId(w.id)+'.');
    return w;
  }
  function applyRoutingClassification(a,result){
    // Явная ссылка на существующую работу важнее неуверенной классификации модели.
    // Напоминание «по работе Р-04» не требует уточнения места: место наследуется от Р-04.
    const referenced=extractWorkReference(a.text,state.works);
    if(referenced){
      const locationConflict=workLocationConflicts(a.text,a.sourceBuilding||a.building,a.sourceRoom||a.room,referenced,state.spaces,a.reporter);
      const explicitCategory=categoryOf(a.text);
      const categoryConflict=explicitCategory!=='прочее'&&referenced.category&&explicitCategory!==referenced.category;
      if(!locationConflict&&!categoryConflict){
        const referenceOwner=ownerForWork(referenced);
        if(!isManagementCompanyOwner(referenceOwner))return sendAppealToClarification(a,{building:referenced.building,room:clarificationRoomForWork(referenced),owner:referenceOwner,force:true,reason:`Указана ${displayWorkId(referenced.id)}, но обслуживание всех помещений этой работы не подтверждено управляющей компанией.`});
        attachToWork(a,referenced,'В тексте обращения указана существующая работа');return 'linked';
      }
    }
    const action=String(result.action||'').toLowerCase();
    let building=String(result.building||a.building||'').trim().toUpperCase();
    let room=String(result.room||a.room||'').trim();
    const coded=room.match(/\b([AB])\s*[-–]?\s*(\d{3})\b/i);
    if(!building&&coded)building=coded[1].toUpperCase();
    if(coded)room=coded[1].toUpperCase()+'-'+coded[2];
    if(!building&&room){const found=state.spaces.find(sp=>norm(sp.room)===norm(room));if(found)building=found.building;}
    const hasLocation=!!(building&&room);
    if(action==='link'){
      const target=state.works.find(w=>workIdKey(w.id)===workIdKey(result.work_id));
      if(target){
        const hardLocationConflict=workLocationConflicts(a.text,a.sourceBuilding||a.building||result.building,a.sourceRoom||a.room||result.room,target,state.spaces,a.reporter);
        const textCategory=categoryOf(a.text+' '+String(result.description||''));
        const hardCategoryConflict=textCategory!=='прочее'&&target.category&&textCategory!==target.category;
        if(!hardLocationConflict&&!hardCategoryConflict){
          const targetOwner=ownerForWork(target);
          if(!isManagementCompanyOwner(targetOwner))return sendAppealToClarification(a,{building:target.building,room:clarificationRoomForWork(target),owner:targetOwner,force:true,reason:`Связь с ${displayWorkId(target.id)} требует проверки обслуживающей организации.`});
          attachToWork(a,target,'Gemini связала обращение с существующей работой');return 'linked';
        }
      }
      // Некорректный или противоречащий адресу номер не принимаем: продолжаем по месту обращения.
      if(hasLocation){
        const fallbackSpace=spaceForAddress(building,room,state.spaces);
        const fallbackOwner=fallbackSpace?.owner||'';
        if(!isManagementCompanyOwner(fallbackOwner))return sendAppealToClarification(a,{building,room,owner:fallbackOwner,reason:'Не удалось подтвердить, что помещение обслуживает управляющая компания.'});
        const created=createRoutedWork(a,{...result,building,room});
        return created?'linked-or-created':sendAppealToClarification(a,{building,room,owner:fallbackOwner,reason:'Не удалось безопасно связать обращение с существующей работой.'});
      }
    }
    const resolvedSpace=spaceForAddress(building,room,state.spaces);
    if(resolvedSpace){building=resolvedSpace.building;room=resolvedSpace.room;a.owner=resolvedSpace.owner||'';a.zone=a.zone||resolvedSpace.zone||'';}
    if(!isManagementCompanyOwner(a.owner||resolvedSpace?.owner||'')){
      return sendAppealToClarification(a,{building,room,owner:a.owner||resolvedSpace?.owner||'',reason:action==='tenant'?'По справочнику обслуживание не относится к управляющей компании.':'Не подтверждено, что помещение обслуживает управляющая компания.'});
    }
    if(action==='create'&&hasLocation){const created=createRoutedWork(a,{...result,building,room});if(created)return 'created';}
    // Для помещений вне зоны обслуживания УК и неизвестного владельца срабатывает
    // очередь уточнения даже при заполненном корпусе и помещении (проверка выше).
    if(action==='clarify'){
      // При полной локации clarify допустим только если справочник не подтверждает обслуживание УК.
      // Для помещения УК с полной локацией решение ниже будет приведено к безопасному create/link.
      if(!isManagementCompanyOwner(ownerForAppeal({...a,building,room})))
        return sendAppealToClarification(a,{building,room,owner:a.owner||resolvedSpace?.owner||'',reason:String(result.reason||'Помещение не подтверждено как обслуживаемое управляющей компанией.')});
    }
    if(!hasLocation){
      return sendAppealToClarification(a,{building,room,owner:a.owner||'',reason:String(result.reason||'Не удалось достоверно определить корпус и помещение.')});
    }
    // Неизвестное действие при заполненном адресе не отправляем в уточнение — сохраняем безопасную локальную классификацию.
    const created=createRoutedWork(a,{...result,building,room});
    return created?'created':sendAppealToClarification(a,{building,room,owner:ownerForAppeal({...a,building,room}),reason:'Не удалось подтвердить помещение и безопасно создать работу.'});
  }
  function queueAutoRouting(appeals){
    for(const item of appeals||[]){
      const fingerprint=appealRoutingFingerprint(item);
      const previous=state.appState.aiRouting?.[item.id];
      if(previous?.fingerprint===fingerprint&&['queued','done','fallback'].includes(previous.status))continue;
      const id=item.id;
      routingQueue=routingQueue.then(async()=>{
        const a=state.appeals.find(x=>x.id===id);if(!a)return;
        if(!hasGeminiConsent())return;
        let status;
        try{status=await getGeminiStatus(true);if(!status.configured)return;}
        catch(error){console.warn('[Диспетчерская] Gemini routing status:',error?.message||error);return;}
        state.appState.aiRouting=state.appState.aiRouting||{};
        state.appState.aiRouting[id]={fingerprint,status:'queued',updatedAt:new Date().toISOString()};
        queueSave();
        try{
          const result=await cloudAIRequest('route',routingContext(a));
          const outcome=applyRoutingClassification(a,result);
          state.appState.aiRouting[id]={fingerprint,status:'done',outcome,updatedAt:new Date().toISOString()};
          addHistory(id,'Автоматическая классификация Gemini: '+outcome+'.');
          updateNav();queueSave();render();
        }catch(error){
          console.warn('[Диспетчерская] Gemini routing fallback:',error?.message||error);
          state.appState.aiRouting[id]={fingerprint,status:'fallback',updatedAt:new Date().toISOString(),reason:String(error?.message||'')};
          queueSave();
        }
      }).catch(error=>console.warn('[Диспетчерская] routing queue:',error));
    }
  }
  function makeResidentReply(a){
    const w=getAppealWork(a);
    const place=[a.building?'корпус '+a.building:'',a.room||''].filter(Boolean).join(', ')||'место требуется уточнить';
    const subject=`Тема: Обращение ${a.id} — ${place}`;
    let stateText='Обращение зарегистрировано и находится на рассмотрении диспетчерской службы.';
    let next='Диспетчерская служба проверит сведения и определит дальнейший порядок передачи обращения ответственному исполнителю.';
    if(a.route==='tenant'){
      const servicing=ownerForAppeal(a)||a.owner||'не указана в справочнике';
      stateText=`По справочнику помещение обслуживает: ${servicing}. Работа управляющей компании по этому обращению не создавалась.`;
      next=`Для дальнейшей обработки обращение необходимо направить обслуживающей организации: ${servicing}.`;
    }else if(w){
      stateText=`Обращение связано с работой ${displayWorkId(w.id)}. Текущий статус работы в системе: «${w.status}». Исполнитель ${w.executor&&norm(w.executor)!=='не назначен'?'назначен':'не назначен'}.`;
      if(norm(w.status)==='закрыто')next='В системе работа отмечена как закрытая. Если неисправность сохраняется или возникла повторно, просим сообщить, когда именно проблема была замечена снова.';
      else if(norm(w.status)==='принято')next='Работа принята исполнителем; после обновления статуса диспетчерская служба сможет сообщить дополнительную информацию.';
      else if(norm(w.status)==='в работе')next='Работа находится в выполнении. После получения отметки исполнителя о результате диспетчерская служба направит обновление.';
      else next='Работа зарегистрирована; диспетчерская служба контролирует её дальнейшее назначение и обновление статуса.';
    }
    const missing=(a.missing||[]).filter(Boolean);
    const clarification=missing.length?`\n\nДля корректной обработки просим уточнить: ${missing.join(', ').toLowerCase()}. До получения этих сведений обращение сохраняется в очереди и не теряется.`:'';
    return `${subject}\n\nЗдравствуйте!\n\nБлагодарим за обращение в управляющую компанию «Квартал Менеджмент». Подтверждаем, что сообщение зарегистрировано в диспетчерской системе под номером ${a.id}${a.time?' (поступило '+a.time+')':''}.\n\nСуть обращения: ${a.text||a.issue||'требуется уточнение описания неисправности'}.\nМесто: ${place}.\n${stateText}\n\n${next}${clarification}\n\nЕсли у вас есть дополнительные сведения, фотографии или уточнения по месту и времени возникновения неисправности, пожалуйста, направьте их ответным сообщением с указанием номера ${a.id}.\n\nС уважением,\nДиспетчерская служба\nУправляющая компания «Квартал Менеджмент»`;
  }
  async function generateResidentReply(a){
    const btn=$('#generateReplyBtn');const area=$('#replyDraftText');
    if(!btn||!area)return;
    btn.disabled=true;btn.textContent='Готовим текст…';
    let answer=makeResidentReply(a);let source='встроенному шаблону';
    try{
      const status=await getGeminiStatus(true);
      if(status.configured&&hasGeminiConsent()){
        const result=await cloudAIRequest('reply',appealAIContext(a));
        const candidate=String(result.text||'').trim();
        if(candidate.length<40)throw new Error('Gemini вернула слишком короткий черновик. Использован безопасный шаблон.');
        answer=candidate;source='Gemini';
      }
    }catch(error){
      console.warn('[Диспетчерская] Gemini unavailable; template fallback used:',error?.message||error);
      source='резервному шаблону';
    }
    a.responseDraft=answer;area.value=answer;
    state.appState.tenantMessages=state.appState.tenantMessages||{};
    state.appState.tenantMessages[a.id]={...(state.appState.tenantMessages[a.id]||{}),responseDraft:answer};
    queueSave();addHistory(a.id,'Подготовлен черновик ответа по '+source+'.');
    const note=$('#replyGenerationNote');
    if(note){
      note.textContent=source==='Gemini'?'Черновик подготовлен Gemini по обезличенным данным обращения. Проверьте адресата и факты перед отправкой.':`Использован ${source}: Gemini не настроена, согласие не дано или сервис временно недоступен. Компьютер не запускает локальную модель.`;
    }
    btn.disabled=false;btn.textContent='Подготовить заново';
  }
  async function openAISettings(){
    $('#overlayRoot').innerHTML=`<div class="overlay modal-overlay" id="aiSettingsOverlay"><div class="modal" style="max-width:560px"><div class="modal-head"><div><div class="eyebrow">ОБЛАЧНЫЙ ИИ · БЕЗ НАГРУЗКИ НА ПК</div><h3>Gemini Flash-Lite</h3></div><button class="close-btn" id="aiClose">×</button></div><div class="modal-body">
      <div class="source-file"><div class="file-icon">G</div><div class="file-meta"><strong>Google Gemini 3.1 Flash-Lite</strong><span>Работает на серверах Google · компьютер не запускает модель</span></div><span class="ai-model-pill">Cloud API</span></div>
      <div class="form-note" style="margin-top:14px">Для бесплатного доступа создай API-ключ в Google AI Studio. Проект использует только модель gemini-3.1-flash-lite, без платных резервных моделей. Автоматическая классификация запускается только для нового или изменённого обращения после моего согласия; ответы и сводки — только по нажатию кнопки.</div>
      <div class="form-field" style="margin-top:14px"><label for="geminiApiKey">API-ключ Google AI Studio</label><input id="geminiApiKey" type="password" autocomplete="new-password" spellcheck="false" placeholder="Вставь ключ; сохранённый ключ не показывается"><div class="form-note">Ключ хранится в личной папке пользователя на сервере, вне папки сайта; в браузер и Git не попадает.</div></div>
      <label class="check-row" style="display:flex;gap:10px;align-items:flex-start;margin-top:12px"><input id="geminiPrivacyConsent" type="checkbox" ${hasGeminiConsent()?'checked':''} style="margin-top:3px"><span>Я согласен отправлять Google необходимые обезличенные фрагменты новых или изменённых обращений для автоматической классификации (извлечение корпуса, помещения и зоны из текста, привязка к работе, создание новой работы или уточнение места), формирования коротких названий проблем, а также для подготовки ответов и сводок. Понимаю, что на бесплатном тарифе Google может использовать отправленный контент для улучшения продуктов. Не отправлять специальные категории персональных данных и конфиденциальные сведения.</span></label>
      <div id="geminiStatusBox" class="soft-note" style="margin-top:14px">Проверяем настройки…</div>
      <div class="form-note" style="margin-top:10px">Перед отправкой сервер скрывает email, телефон и некоторые явные упоминания имени. Но автоматическое обезличивание не гарантирует удаление всех персональных данных: проверь текст обращения самостоятельно. Если бесплатная квота закончится, ИИ-запрос остановится и будет использован шаблон.</div>
    </div><div class="modal-foot" style="flex-wrap:wrap"><button class="btn btn-light" id="aiCancel">Закрыть</button><button class="btn btn-light" id="clearGeminiKey">Удалить ключ</button><button class="btn btn-light" id="testGeminiKey">Проверить ключ</button><button class="btn btn-primary" id="saveGeminiKey">Сохранить ключ</button></div></div></div>`;
    const statusBox=$('#geminiStatusBox');
    const refreshStatus=async()=>{
      try{const status=await getGeminiStatus(true);statusBox.textContent=status.configured?`Ключ настроен · модель ${status.model}. Согласие на отправку ${hasGeminiConsent()?'дано':'пока не дано'}.`:'API-ключ ещё не настроен. Пока будут использоваться шаблоны.';statusBox.className='soft-note '+(status.configured?'success-text':'');}
      catch(e){statusBox.textContent='Не удалось прочитать настройки: '+e.message;statusBox.className='soft-note';}
    };
    $('#aiClose').onclick=closeOverlay;$('#aiCancel').onclick=closeOverlay;
    $('#aiSettingsOverlay').addEventListener('click',e=>{if(e.target.id==='aiSettingsOverlay')closeOverlay();});
    const queueLatestUnprocessed=()=>{
      const latest=[...state.appeals].reverse().find(a=>{
        const saved=state.appState.aiRouting?.[a.id];
        return !saved||saved.fingerprint!==appealRoutingFingerprint(a);
      });
      if(latest)queueAutoRouting([latest]);
    };
    $('#geminiPrivacyConsent').onchange=e=>{setGeminiConsent(!!e.target.checked);if(e.target.checked)queueLatestUnprocessed();};
    $('#saveGeminiKey').onclick=async()=>{
      const key=$('#geminiApiKey').value.trim();
      if(!key){statusBox.textContent='Вставь новый API-ключ. Существующий ключ не отображается.';return;}
      const btn=$('#saveGeminiKey');btn.disabled=true;
      try{const r=await fetch('/api/ai/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({apiKey:key})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Не удалось сохранить ключ');$('#geminiApiKey').value='';geminiStatusCache=null;await refreshStatus();statusBox.textContent='Ключ сохранён на сервере. Теперь нажми «Проверить ключ».';if(hasGeminiConsent())queueLatestUnprocessed();toast('API-ключ сохранён');}
      catch(e){statusBox.textContent=e.message;}
      finally{btn.disabled=false;}
    };
    $('#testGeminiKey').onclick=async()=>{
      const btn=$('#testGeminiKey');btn.disabled=true;
      try{
        setGeminiConsent($('#geminiPrivacyConsent').checked);
        const typed=$('#geminiApiKey').value.trim();
        if(typed){
          const save=await fetch('/api/ai/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({apiKey:typed})});
          const saved=await save.json();if(!save.ok)throw new Error(saved.error||'Не удалось сохранить ключ');
          $('#geminiApiKey').value='';geminiStatusCache=null;
        }
        statusBox.textContent='Отправляем один короткий тестовый запрос в Google…';
        const r=await fetch('/api/ai/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});
        const d=await r.json();if(!r.ok)throw new Error(d.error||'Проверка не пройдена');
        await refreshStatus();statusBox.textContent=`Подключение успешно · ${d.model}. ${d.message||''}`;statusBox.className='soft-note success-text';toast('Gemini подключена');
      }catch(e){statusBox.textContent=e.message;statusBox.className='soft-note';}
      finally{btn.disabled=false;}
    };
    $('#clearGeminiKey').onclick=async()=>{
      if(!confirm('Удалить сохранённый API-ключ Gemini с этого сервера?'))return;
      try{const r=await fetch('/api/ai/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'clear'})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Не удалось удалить ключ');geminiStatusCache=null;await refreshStatus();toast('Ключ удалён');}
      catch(e){statusBox.textContent=e.message;}
    };
    await refreshStatus();
  }
  function makeBriefFallback(group,records){
    if(!group)return 'В книге пока нет зарегистрированных работ. Новые обращения появятся в разделе «Входящие» после загрузки или добавления данных.';
    const places=(group.rooms||[]).map(r=>roomInputValue(r,group.building)).filter(Boolean);
    const clarification=records.filter(requiresClarification);
    const lines=[`Работа: ${displayWorkId(group.id)}.`,`Проблема: ${group.description||'описание не указано'}.`,`Место: ${[group.building?'корпус '+group.building:'',places.join(', ')||group.location||'помещение не указано'].filter(Boolean).join(', ')}.`,`Зона обслуживания: ${group.zone||'не указана'}.`,`Статус: ${group.status||'не указан'}.`,`Исполнитель: ${group.executor&&norm(group.executor)!=='не назначен'?'назначен':'не назначен'}.`,`Связано обращений: ${records.length}.`];
    if(clarification.length)lines.push(`Требуют уточнения: ${clarification.map(a=>a.id).join(', ')}.`);
    if(records.length){const descriptions=[...new Set(records.map(a=>String(a.text||'').trim()).filter(Boolean))].slice(0,3);if(descriptions.length)lines.push('Сообщения: '+descriptions.join(' / '));}
    return lines.join(' ');
  }
  async function generateBrief(workId=null){
    const btn=$('#aiBriefBtn');if(btn){btn.disabled=true;btn.textContent='Формируем…';}
    const group=state.works.find(w=>w.id===workId)||state.works.find(w=>w.id==='Р-01')||[...state.works].sort((a,b)=>(b.appealIds||[]).length-(a.appealIds||[]).length)[0]||null;
    const records=group?state.appeals.filter(a=>(group.appealIds||[]).includes(a.id)):[];
    let summary=makeBriefFallback(group,records);let source='по правилам проекта';
    try{
      const status=await getGeminiStatus(true);
      if(status.configured&&hasGeminiConsent()&&group){
        const context={id:group.id,issue:group.category||'',work_description:group.description||'',building:group.building||'',room:group.location||((group.rooms||[]).join(', ')),zone:group.zone||'',work_status:group.status||'',executor_assigned:!!(group.executor&&norm(group.executor)!=='не назначен'),appeal_count:records.length,appeal_ids:records.map(a=>a.id),clarification_ids:records.filter(requiresClarification).map(a=>a.id),descriptions:records.map(a=>a.text||'').filter(Boolean).slice(0,8),previous_work:group.previousWork||''};
        const response=await cloudAIRequest('brief',context);if(String(response.text||'').trim().length>40){summary=String(response.text).trim();source='Gemini';}
      }
    }catch(error){console.warn('[Диспетчерская] Brief fallback:',error?.message||error);source='резервным правилам (Gemini недоступна)';}
    if(group){group.aiSummary=summary;queueSave();}
    showSummaryModal(summary,'Сводка по работе '+(group?displayWorkId(group.id):''),`Сформировано ${source}. Проверьте статусы и факты перед использованием.`);
    if(btn){btn.disabled=false;btn.textContent='Сформировать сводку';}
  }

  function showSummaryModal(text,title,note='Сформировано по данным книги Excel. Проверьте факты перед использованием.'){
    $('#overlayRoot').innerHTML=`<div class="overlay modal-overlay" id="summaryOverlay"><div class="modal" style="max-width:480px"><div class="modal-head"><div><div class="eyebrow">КРАТКО И ПО ДЕЛУ</div><h3>${esc(title)}</h3></div><button class="close-btn" id="summaryClose">×</button></div><div class="modal-body"><div class="detail-message">${esc(text)}</div><div class="form-note">${esc(note)}</div></div><div class="modal-foot"><button class="btn btn-light" id="summaryClose2">Закрыть</button><button class="btn btn-primary" id="copySummary">Копировать</button></div></div></div>`;
    $('#summaryClose').onclick=closeOverlay;$('#summaryClose2').onclick=closeOverlay;
    $('#summaryOverlay').addEventListener('click',e=>{if(e.target.id==='summaryOverlay')closeOverlay();});
    $('#copySummary').onclick=()=>{navigator.clipboard?.writeText(text);toast('Сводка скопирована');};
  }

  function downloadCSV(){const rows=[['Работа','Корпус','Помещение','Статус','Исполнитель','Обращения'],...state.works.map(w=>[displayWorkId(w.id),w.building,w.location,w.status,w.executor,w.appealIds.join(', ')])];const csv='\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(';')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='Диспетчерская_работы.csv';a.click();URL.revokeObjectURL(url);}
  async function replaceFile(file){if(!file)return;if(!file.name.toLowerCase().endsWith('.xlsx')){toast('Нужен файл Excel .xlsx','error');return;}if(file.size>20*1024*1024){toast('Файл больше 20 МБ','error');return;}toast('Читаю книгу Excel…');try{const response=await fetch('/api/import',{method:'POST',headers:{'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','X-Filename':encodeURIComponent(file.name)},body:file});const data=await response.json();if(!response.ok)throw new Error(data.error||'Не удалось прочитать файл');loadData(data.sheets,file.name,data.revision,data.appState,data.appRevision);setSyncStatus('Excel синхронизирован','sync-ok');toast(`Загружен файл ${file.name}`);}catch(e){toast(e.message,'error');}}

  document.addEventListener('click',e=>{
    const nav=e.target.closest('[data-view]');if(nav){go(nav.dataset.view);return;}
    const goBtn=e.target.closest('[data-go]');if(goBtn){go(goBtn.dataset.go);return;}
    const kpi=e.target.closest('[data-kpi-filter]');if(kpi){state.filter=state.filter===kpi.dataset.kpiFilter?'all':kpi.dataset.kpiFilter;render();return;}
    const tenantMessage=e.target.closest('[data-tenant-message]');if(tenantMessage){openTenantMessage(tenantMessage.dataset.tenantMessage);return;}
    const problemWork=e.target.closest('[data-problem-work]');if(problemWork){openProblemWork(problemWork.dataset.problemWork);return;}
    const appealMessage=e.target.closest('[data-appeal-message]');if(appealMessage){openTenantMessage(appealMessage.dataset.appealMessage);return;}
    const appeal=e.target.closest('[data-appeal]');if(appeal){openAppeal(appeal.dataset.appeal);return;}
    const work=e.target.closest('[data-work]');if(work){const w=state.works.find(x=>x.id===work.dataset.work);if(w)openWork(w.id);return;}
    if(e.target.closest('#quickNewBtn')){openAppealForm();return;}
    if(e.target.closest('#aiSettingsBtn')){openAISettings();return;}
    if(e.target.closest('#aiBriefBtn')){generateBrief();return;}
    if(e.target.closest('#showExampleBtn')){const w=state.works.find(x=>workIdKey(x.id)==='Р1');if(w)openWork(w.id);return;}
    if(e.target.closest('#downloadCsvBtn')){downloadCSV();return;}
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeOverlay();});
  document.addEventListener('input',e=>{
    if(e.target.id==='appealSearch'){state.query=e.target.value;const pos=e.target.selectionStart;render();const el=$('#appealSearch');el?.focus();el?.setSelectionRange(pos,pos);}
    if(e.target.id==='workSearch'){state.query=e.target.value;const pos=e.target.selectionStart;render();const el=$('#workSearch');el?.focus();el?.setSelectionRange(pos,pos);}
  });
  document.addEventListener('change',e=>{
    if(e.target.id==='replaceFile'){replaceFile(e.target.files?.[0]);e.target.value='';}
    if(e.target.id==='appealFilter'){state.filter=e.target.value;render();}
    if(e.target.id==='appealChannelFilter'){state.appealChannelFilter=e.target.value;render();}
    if(e.target.id==='appealBuildingFilter'){state.appealBuildingFilter=e.target.value;render();}
    if(e.target.id==='overviewBuildingFilter'){state.overviewBuildingFilter=e.target.value;render();}
    if(e.target.id==='workFilter'){state.workStatusFilter=e.target.value;render();}
    if(e.target.id==='workSort'){state.workSort=e.target.value;render();}
  });

  function openWork(id){openWorkDetail(id);}
  function openWorkDetail(id){
    const w=state.works.find(x=>x.id===id);if(!w)return;
    state.selectedWork=id;
    const group=problemGroups().find(g=>g.work?.id===id)||null;
    const ctx=workContext(w,group);
    const linked=state.appeals.filter(a=>w.appealIds.includes(a.id));
    const linkedMarkup=linked.map(a=>`<button class="work-linked-message" type="button" data-tenant-message="${esc(a.id)}"><strong>${esc(a.reporter||'Заявитель не указан')}</strong><span>${esc(a.text||'')}</span><small>${esc(a.time||'')} · ${esc(a.channel||'Канал не указан')}</small></button>`).join('');
    const old=$('#workDetailOverlay');if(old)old.remove();
    const node=document.createElement('div');node.className='overlay work-detail-overlay';node.id='workDetailOverlay';
    node.innerHTML=`<section class="work-detail-modal" role="dialog" aria-modal="true" aria-labelledby="workDetailTitle">
      <div class="appeal-modal-head"><div class="appeal-modal-title"><div class="eyebrow">КАРТОЧКА РАБОТЫ</div><div class="appeal-modal-id" id="workDetailTitle">${esc(displayWorkId(w.id))}</div><div class="detail-place-line">${esc(problemTitleForWork(w))}</div><div class="detail-place-line">${esc(ctx.building?'Корпус '+ctx.building:'Корпус не указан')} · ${esc(ctx.room||'Помещение не указано')}</div></div><div class="appeal-modal-actions"><span class="status ${statusClass(w.status)}">${esc(statusLabel(w.status))}</span><button type="button" class="close-btn" id="workDetailClose" aria-label="Закрыть">×</button></div></div>
      <div class="work-detail-body">
        <section class="detail-card"><div class="detail-card-head"><span class="detail-card-title">Данные работы</span><button class="btn btn-light btn-small" id="aiBriefBtn">Сводка ИИ</button></div>
          <div class="tenant-source-grid work-detail-fields"><div class="tenant-source-field"><span>Корпус</span><strong>${esc(ctx.building||'Не указан')}</strong></div><div class="tenant-source-field"><span>Помещение</span><strong>${esc(ctx.room||'Не указано')}</strong></div><div class="tenant-source-field"><span>Зона обслуживания</span><strong>${esc(ctx.zone||'Не указана')}</strong></div><div class="tenant-source-field"><span>Исполнитель</span><strong>${esc(w.executor||'Не назначен')}</strong></div><div class="tenant-source-field"><span>Связанные обращения</span><strong>${linked.length}</strong></div></div><div class="work-detail-stacked-fields"><div class="work-detail-value-field"><span>Обновлено</span><strong>${esc(w.updated||'—')}</strong></div><div class="work-detail-description-field"><span>Описание работы</span><strong>${esc(w.description||'Описание не заполнено')}</strong></div></div>
        </section>
        <section class="detail-card"><div class="detail-card-head"><span class="detail-card-title">Обращения арендаторов</span><span class="panel-hint">${linked.length}</span></div><div class="work-linked-list">${linkedMarkup||'<div class="empty-state">Нет связанных обращений</div>'}</div></section>
      </div>
    </section>`;
    $('#overlayRoot').appendChild(node);
    $('#workDetailClose').onclick=()=>{node.remove();state.selectedWork=null;};
    node.addEventListener('click',e=>{if(e.target===node){node.remove();state.selectedWork=null;}});
  }
  function editWork(w){
    const ctx=workContext(w,problemGroups().find(g=>g.work?.id===w.id)||null);
    const node=document.createElement('div');node.className='overlay modal-overlay work-edit-overlay';node.id='workEditOverlay';
    node.innerHTML=`<div class="modal work-edit-modal" role="dialog" aria-modal="true"><div class="modal-head"><div><div class="eyebrow">${esc(displayWorkId(w.id))}</div><h3>Изменить работу</h3></div><button class="close-btn" id="workEditClose" aria-label="Закрыть">×</button></div><div class="modal-body">
      <div class="work-edit-summary"><strong>${esc(displayWorkId(w.id))}</strong><span>${esc(ctx.building?'Корпус '+ctx.building:'Корпус не указан')} · ${esc(ctx.room||'Помещение не указано')} · ${esc(ctx.zone||'Зона не указана')}</span></div>
      <div class="form-grid"><div class="form-field"><label>Корпус</label><select id="workBuilding"><option value="">Не указан</option><option value="A" ${ctx.building==='A'?'selected':''}>A</option><option value="B" ${ctx.building==='B'?'selected':''}>B</option></select></div><div class="form-field"><label>Помещение</label><input id="workLocation" value="${esc(ctx.rawLocation||ctx.room)}"></div><div class="form-field"><label>Зона обслуживания</label><input id="workZone" value="${esc(ctx.zone)}"></div><div class="form-field"><label>Статус работы</label><select id="workStatus">${['открыто','принято','в работе','закрыто'].map(s=>`<option value="${s}" ${norm(s)===norm(w.status)?'selected':''}>${s}</option>`).join('')}</select></div><div class="form-field full"><label>Исполнитель</label><input id="workExecutor" value="${esc(w.executor||'')}"></div><div class="form-field full work-description-field"><label for="workDescription">Описание работы</label><textarea id="workDescription" class="work-description-editor" rows="5" spellcheck="true">${esc(w.description||'')}</textarea></div></div>
      <div class="form-note">Изменения сохранятся в рабочей книге Excel.</div></div><div class="modal-foot"><button class="btn btn-light" id="workEditCancel">Отмена</button><button class="btn btn-primary" id="workEditSave">Сохранить изменения</button></div></div>`;
    $('#overlayRoot').appendChild(node);
    const closeEdit=()=>node.remove();
    $('#workEditClose').onclick=closeEdit;$('#workEditCancel').onclick=closeEdit;
    node.addEventListener('click',e=>{if(e.target===node)closeEdit();});
    $('#workEditSave').onclick=()=>{
      const prevStatus=w.status;const prevDescription=w.description;const prevExecutor=w.executor;w.building=$('#workBuilding').value.trim().toUpperCase();w.location=(roomList($('#workLocation').value).length?roomList($('#workLocation').value).join(', '):canonicalRoomValue($('#workLocation').value,w.building));w.rooms=roomList(w.location);if(!w.rooms.length&&w.location){const matchedSpace=state.spaces.find(sp=>norm(sp.room)===norm(w.location)&&(!w.building||sp.building.toUpperCase()===w.building));w.rooms=[matchedSpace?.room||w.location];}w.zone=$('#workZone').value.trim();w.status=$('#workStatus').value;w.executor=$('#workExecutor').value.trim();w.description=$('#workDescription').value.trim();if(prevDescription!==w.description&&state.appState?.problemTitles)delete state.appState.problemTitles[w.id];
      const statusChanged=norm(prevStatus)!==norm(w.status);
      if(statusChanged)w.updated=workStamp();
      state.spaces.forEach(sp=>{if(norm(sp.room)===norm(w.location)&&(!w.building||sp.building.toUpperCase()===w.building))w.zone=w.zone||sp.zone;});
      const changed=[];if(statusChanged)changed.push(`статус: ${prevStatus||'не указан'} → ${w.status}`);if(prevExecutor!==w.executor)changed.push(`исполнитель: ${prevExecutor||'не назначен'} → ${w.executor||'не назначен'}`);if(prevDescription!==w.description)changed.push('обновлено описание работы');if(!changed.length)changed.push('проверены данные работы');
      const historyText=`Работа ${displayWorkId(w.id)}: ${changed.join('; ')}.`;
      const linkedForHistory=state.appeals.filter(a=>w.appealIds.includes(a.id));
      if(linkedForHistory.length)linkedForHistory.forEach(a=>addHistory(a.id,historyText));
      if(prevStatus!==w.status&&isResolvedStatus(w.status))toast('Проблема перемещена во вкладку «Решённые проблемы»');
      const detailWasOpen=!!$('#workDetailOverlay');
      closeEdit();
      if($('#workDetailOverlay'))$('#workDetailOverlay').remove();
      state.selectedWork=detailWasOpen?w.id:null;
      updateNav();queueSave();toast('Работа обновлена и записана в Excel');
      render();
    };
  }
  // Навигация раскрывается только при наведении мыши; состояние не переключается кликом.

  // Стартуем из общей рабочей книги на сервере; sessionStorage не является источником данных.
  (async()=>{
    try{
      const response=await fetch('/api/bootstrap',{cache:'no-store'});const data=await response.json();
      if(!response.ok)throw new Error(data.error||'Не удалось загрузить рабочую книгу');
      loadData(data.sheets,data.name,data.revision,data.appState,data.appRevision);setSyncStatus('Excel синхронизирован','sync-ok');
    }catch(e){
      try{
        loadData(window.DEMO_DATA,'case_data.xlsx','');
        setSyncStatus('Демо-режим · нет связи','sync-warn');
        toast('Не удалось подключиться к рабочей книге: '+e.message,'error');
      }catch(fallbackError){
        showStartupError(fallbackError);
      }
    }
    setInterval(pollWorkbook,2500);
  })();
})();
